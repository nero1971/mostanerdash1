import React, { useEffect, useRef, useState } from "react";
import { GameEngine } from "./game/GameEngine";
import { GameState } from "./types/game";
import { TitleScreen } from "./ui/TitleScreen";
import { HudOverlay } from "./ui/HudOverlay";
import { VirtualControls } from "./ui/VirtualControls";
import { PhoneApp, Smartphone } from "./ui/Smartphone";
import { WorldMapModal } from "./ui/WorldMapModal";
import { PauseModal } from "./ui/PauseModal";
import { MissionSuccessModal } from "./ui/MissionSuccessModal";
import { BaaperRastaIntroModal } from "./ui/BaaperRastaIntroModal";
import { MISSIONS } from "./game/constants";

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [engine, setEngine] = useState<GameEngine | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [gameState, setGameState] = useState<GameState>("INTRO_MODAL");
  const [hudTick, setHudTick] = useState(0);

  // Modals & Overlays
  const [isPhoneOpen, setIsPhoneOpen] = useState(false);
  const [phoneDefaultApp, setPhoneDefaultApp] = useState<PhoneApp>("HOME");
  const [isMapOpen, setIsMapOpen] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Handle full-viewport resolution
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Initialize Game Engine once
    const newEngine = new GameEngine(canvas);
    engineRef.current = newEngine;
    setEngine(newEngine);

    newEngine.onStateChange = (nextState) => {
      setGameState(nextState);
    };

    newEngine.onHudUpdate = () => {
      setHudTick((t) => t + 1);
    };

    // Start 60fps simulation
    newEngine.start();

    // Hotkey for Phone (P) and Map (M)
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (newEngine.state !== "PLAYING") return;
      if (e.code === "KeyP") {
        setIsPhoneOpen((prev) => !prev);
      } else if (e.code === "KeyM") {
        setIsMapOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleGlobalKey);

    return () => {
      window.removeEventListener("resize", resizeCanvas);
      window.removeEventListener("keydown", handleGlobalKey);
      newEngine.stop();
    };
  }, []);

  return (
    <main className="fixed inset-0 w-full h-[100dvh] overflow-hidden bg-stone-950 font-bangla select-none touch-none">
      {/* 60fps Isolated Game Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full block touch-none"
      />

      {/* 0. "বাপের রাস্তা" Welcome / Intro Modal */}
      {gameState === "INTRO_MODAL" && engine && (
        <BaaperRastaIntroModal
          engine={engine}
          onStart={() => {
            engine.setState("PLAYING");
          }}
        />
      )}

      {/* 1. Title Screen Shell */}
      {gameState === "TITLE" && engine && (
        <div className="absolute inset-0 z-40">
          <TitleScreen
            engine={engine}
            onPlay={() => {
              engine.setState("PLAYING");
            }}
            onOpenMissions={() => {
              setPhoneDefaultApp("MISSIONS");
              setIsPhoneOpen(true);
            }}
            onOpenMap={() => {
              setIsMapOpen(true);
            }}
            onOpenGarage={() => {
              setPhoneDefaultApp("GARAGE");
              setIsPhoneOpen(true);
            }}
            onOpenSettings={() => {
              setPhoneDefaultApp("SETTINGS");
              setIsPhoneOpen(true);
            }}
          />
        </div>
      )}

      {/* 2. In-Game Low-Occlusion HUD Overlay */}
      {gameState === "PLAYING" && engine && (
        <>
          <HudOverlay
            engine={engine}
            onOpenMap={() => setIsMapOpen(true)}
            onOpenPhone={() => {
              setPhoneDefaultApp("HOME");
              setIsPhoneOpen(true);
            }}
            onPause={() => engine.setState("PAUSED")}
          />

          {/* Virtual Touch Joystick & Action Buttons */}
          <VirtualControls
            engine={engine}
            onOpenPhone={() => {
              setPhoneDefaultApp("HOME");
              setIsPhoneOpen(true);
            }}
            onOpenMap={() => setIsMapOpen(true)}
          />
        </>
      )}

      {/* 3. Pause Modal */}
      {gameState === "PAUSED" && engine && (
        <PauseModal
          engine={engine}
          onResume={() => engine.setState("PLAYING")}
          onOpenMissions={() => {
            setPhoneDefaultApp("MISSIONS");
            setIsPhoneOpen(true);
          }}
          onOpenMap={() => setIsMapOpen(true)}
          onOpenSettings={() => {
            setPhoneDefaultApp("SETTINGS");
            setIsPhoneOpen(true);
          }}
          onMainMenu={() => engine.setState("TITLE")}
        />
      )}

      {/* 4. Mission Success Modal */}
      {gameState === "MISSION_SUCCESS" && engine && (
        <MissionSuccessModal
          rewardMoney={
            MISSIONS.find(
              (m) =>
                m.id ===
                engine.completedMissions[engine.completedMissions.length - 1]
            )?.rewardMoney || 200
          }
          completedCount={engine.completedMissions.length}
          totalMissions={MISSIONS.length}
          onContinue={() => engine.setState("PLAYING")}
        />
      )}

      {/* 5. In-Game Smartphone Overlay */}
      {isPhoneOpen && engine && (
        <Smartphone
          engine={engine}
          defaultApp={phoneDefaultApp}
          onClose={() => setIsPhoneOpen(false)}
        />
      )}

      {/* 6. Full World Map Modal */}
      {isMapOpen && engine && (
        <WorldMapModal
          engine={engine}
          onClose={() => setIsMapOpen(false)}
        />
      )}
    </main>
  );
}

export default App;
