import React from "react";
import { GameEngine } from "../game/GameEngine";
import { soundManager } from "../audio/SoundManager";
import { Minimap } from "./Minimap";
import {
  Bell,
  Clock,
  Coffee,
  Heart,
  MapPin,
  Pause,
  Phone,
  ShieldAlert,
  Smartphone,
  Star,
  Volume2,
  VolumeX,
} from "lucide-react";

interface HudOverlayProps {
  engine: GameEngine;
  onOpenMap: () => void;
  onOpenPhone: () => void;
  onPause: () => void;
}

export const HudOverlay: React.FC<HudOverlayProps> = ({
  engine,
  onOpenMap,
  onOpenPhone,
  onPause,
}) => {
  const currentVeh = engine.vehicles.find((v) => v.id === engine.player.currentVehicleId);
  const activeMission = engine.activeMission;
  const weapon = engine.player.weapon;

  const weaponIcon =
    weapon === "ramdao"
      ? "🗡️"
      : weapon === "bomb"
      ? "💣"
      : weapon === "pistol"
      ? "🔫"
      : weapon === "shotgun"
      ? "💥"
      : weapon === "rifle"
      ? "🎯"
      : weapon === "bamboo_stick"
      ? "🎋"
      : "🥊";

  const weaponName =
    weapon === "ramdao"
      ? "রামদা"
      : weapon === "bomb"
      ? "হাতবোমা"
      : weapon === "pistol"
      ? "পিস্তল"
      : weapon === "shotgun"
      ? "শটগান"
      : weapon === "rifle"
      ? "রাইফেল"
      : weapon === "bamboo_stick"
      ? "লাঠি"
      : "ঘুষি";

  const ammoCount =
    weapon === "pistol" || weapon === "shotgun" || weapon === "rifle"
      ? engine.player.ammo[weapon]
      : weapon === "bomb"
      ? engine.player.ammo.bomb
      : null;

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex flex-col justify-between font-bangla">
      {/* ========================================================
          TOP ULTRA-COMPACT STATUS BAR (Never intrudes or covers gameplay)
         ======================================================== */}
      <header className="w-full px-2 sm:px-4 pt-2 sm:pt-3 flex items-center justify-between pointer-events-auto gap-2">
        {/* Left Side: Consolidated Health, Cash, & Equipped Weapon Pill */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="flex items-center gap-2 bg-stone-950/85 backdrop-blur-md border border-emerald-500/50 px-2.5 py-1 rounded-full shadow-lg">
            {/* Health */}
            <div className="flex items-center gap-1">
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 shrink-0" />
              <div className="w-14 sm:w-20 h-1.5 bg-stone-800 rounded-full overflow-hidden border border-stone-700">
                <div
                  style={{ width: `${engine.player.health}%` }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-green-400"
                />
              </div>
              <span className="text-[10px] font-bold text-stone-200 tabular-nums">
                {engine.player.health}%
              </span>
            </div>

            <span className="text-stone-600 text-xs">|</span>

            {/* Money */}
            <div className="flex items-center gap-0.5">
              <span className="text-xs font-bold text-amber-400">৳</span>
              <span className="text-xs font-bold text-amber-300 tabular-nums">
                {engine.player.money}
              </span>
            </div>

            <span className="text-stone-600 text-xs">|</span>

            {/* Equipped Weapon Badge (Tap to cycle weapon) */}
            <button
              onClick={() => engine.switchWeapon()}
              className="flex items-center gap-1 text-[10px] font-bold text-emerald-300 hover:text-emerald-200 cursor-pointer active:scale-95 transition-transform"
              title="অস্ত্র পরিবর্তন (Q)"
            >
              <span>{weaponIcon}</span>
              <span>{weaponName}</span>
              {ammoCount !== null && (
                <span className="text-[9px] font-mono text-amber-300 font-bold bg-stone-900 px-1 py-0.2 rounded border border-amber-500/30">
                  {ammoCount}
                </span>
              )}
            </button>
          </div>

          {/* Wanted Stars (if police alert active) */}
          {engine.player.wantedLevel > 0 && (
            <div className="flex items-center gap-0.5 bg-rose-950/90 border border-rose-500/80 px-2 py-1 rounded-full shadow">
              <ShieldAlert className="w-3 h-3 text-rose-400 mr-0.5" />
              {Array.from({ length: 3 }).map((_, i) => (
                <span
                  key={i}
                  className={
                    i < engine.player.wantedLevel
                      ? "text-amber-400 text-xs animate-pulse"
                      : "text-stone-600 text-xs"
                  }
                >
                  ★
                </span>
              ))}
            </div>
          )}

          {/* Interior Exit Pill (if inside house/shop) */}
          {engine.player.currentInterior && (
            <button
              onClick={() => engine.handleActionPress()}
              className="flex items-center gap-1 bg-gradient-to-r from-rose-700 to-red-600 border border-rose-300 text-white px-2.5 py-1 rounded-full text-[10px] font-bold shadow-lg cursor-pointer active:scale-95 transition-transform"
            >
              <span>🚪 বের হন (E)</span>
            </button>
          )}

          {/* Speedometer if driving */}
          {currentVeh && (
            <div className="hidden sm:flex items-center gap-1 bg-stone-950/80 border border-cyan-500/50 px-2 py-1 rounded-full text-[10px] text-cyan-300 font-bold">
              <span>🚗 {currentVeh.nameBn}:</span>
              <span className="font-mono">{Math.round(Math.abs(currentVeh.speed) * 12)} km/h</span>
            </div>
          )}
        </div>

        {/* Center: Slim Mission Indicator (Desktop & Tablet) */}
        {activeMission && (
          <div className="hidden md:flex items-center gap-2 bg-stone-950/85 backdrop-blur-md border border-rose-500/50 px-3 py-1 rounded-full shadow-lg text-xs font-bold text-rose-300">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span className="truncate max-w-[200px]">{activeMission.titleBn}</span>
            {engine.missionTimer !== null && (
              <span className="text-amber-400 font-mono text-[10px]">
                ({Math.ceil(engine.missionTimer)}s)
              </span>
            )}
          </div>
        )}

        {/* Right Side: Quick Action Icons & Minimap */}
        <div className="flex items-center gap-1.5">
          {/* Quick Phone Icon */}
          <button
            onClick={() => {
              soundManager.playUiClick();
              onOpenPhone();
            }}
            className="p-1.5 rounded-full bg-stone-950/80 hover:bg-stone-900 border border-emerald-500/50 text-emerald-300 shadow cursor-pointer active:scale-90 transition-transform"
            title="মোবাইল ফোন (P)"
          >
            <Smartphone className="w-3.5 h-3.5" />
          </button>

          {/* Quick World Map Icon */}
          <button
            onClick={() => {
              soundManager.playUiClick();
              onOpenMap();
            }}
            className="p-1.5 rounded-full bg-stone-950/80 hover:bg-stone-900 border border-emerald-500/50 text-emerald-300 shadow cursor-pointer active:scale-90 transition-transform"
            title="মানচিত্র / ম্যাপ (M)"
          >
            <MapPin className="w-3.5 h-3.5" />
          </button>

          {/* Quick Tea Button */}
          <button
            onClick={() => engine.drinkTea()}
            className="p-1.5 rounded-full bg-amber-900/80 hover:bg-amber-800 border border-amber-400 text-amber-200 shadow cursor-pointer active:scale-90 transition-transform"
            title="দুধ চা খান (T) - গতি বাড়বে"
          >
            <Coffee className="w-3.5 h-3.5" />
          </button>

          {/* Audio Mute/Unmute */}
          <button
            onClick={() => {
              const next = !engine.settings.sound.muted;
              engine.settings.sound.muted = next;
              soundManager.updateVolumes(engine.settings.sound);
            }}
            className="p-1.5 rounded-full bg-stone-950/80 hover:bg-stone-900 border border-stone-700 text-stone-300 shadow cursor-pointer active:scale-90 transition-transform"
            title="সাউন্ড অন/অফ"
          >
            {engine.settings.sound.muted ? (
              <VolumeX className="w-3.5 h-3.5 text-rose-400" />
            ) : (
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            )}
          </button>

          {/* Pause Button */}
          <button
            onClick={onPause}
            className="p-1.5 rounded-full bg-stone-950/80 hover:bg-stone-900 border border-stone-700 text-stone-300 shadow cursor-pointer active:scale-90 transition-transform"
            title="পজ (Esc)"
          >
            <Pause className="w-3.5 h-3.5" />
          </button>

          {/* Minimap (Compact) */}
          {engine.settings.showMinimap && (
            <div className="ml-1 hidden sm:block">
              <Minimap engine={engine} onOpenFullMap={onOpenMap} />
            </div>
          )}
        </div>
      </header>

      {/* ========================================================
          SLIM FLOATING NOTIFICATION TOAST
          (Placed at top-center under header, NEVER blocks center of screen)
         ======================================================== */}
      {engine.notification && (
        <div className="self-center mt-2 mx-4 max-w-sm sm:max-w-md bg-stone-950/90 backdrop-blur-md border border-emerald-500/60 px-3 py-1.5 rounded-2xl shadow-xl text-center pointer-events-none animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="text-[11px] font-black text-emerald-300 flex items-center justify-center gap-1">
            <span>📢</span>
            <span>{engine.notification.title}</span>
          </div>
          <p className="text-[10px] text-stone-200 mt-0.5 leading-snug font-medium line-clamp-2">
            {engine.notification.desc}
          </p>
        </div>
      )}

      {/* ========================================================
          MOBILE BOTTOM MISSION STRIP
         ======================================================== */}
      {activeMission && (
        <div className="md:hidden self-center mb-24 px-3 py-1 rounded-full bg-stone-950/85 backdrop-blur-md border border-rose-500/60 text-center shadow-lg pointer-events-auto">
          <div className="text-[10px] font-bold text-rose-400 flex items-center justify-center gap-1">
            <span>⭐ {activeMission.titleBn}</span>
            {engine.missionTimer !== null && (
              <span className="text-amber-300 font-mono">({Math.ceil(engine.missionTimer)}s)</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
