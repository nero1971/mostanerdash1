import {
  Building,
  Dacoit,
  Mission,
  NPC,
  Particle,
  Player,
  PoliceOfficer,
  Region,
  TimeOfDay,
  Vehicle,
  WeatherType,
} from "../types/game";
import { REGIONS, RIVER_X, WORLD_HEIGHT, WORLD_WIDTH } from "./constants";

export class GameRenderer {
  private ctx: CanvasRenderingContext2D;
  private animTimer = 0;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
  }

  public setContext(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
  }

  public render(
    player: Player,
    vehicles: Vehicle[],
    npcs: NPC[],
    dacoits: Dacoit[],
    policeOfficer: PoliceOfficer,
    buildings: Building[],
    particles: Particle[],
    activeMission: Mission | null,
    camera: { x: number; y: number; zoom: number; shake: number },
    timeOfDay: TimeOfDay,
    weather: WeatherType,
    dt: number
  ) {
    this.animTimer += dt;
    const ctx = this.ctx;
    const canvas = ctx.canvas;
    const viewW = canvas.width;
    const viewH = canvas.height;

    // Check if player is inside an enterable shop / interior
    if (player.currentInterior) {
      this.drawShopInterior(player, viewW, viewH);
      return;
    }

    // Clear screen
    ctx.fillStyle = "#1e293b";
    ctx.fillRect(0, 0, viewW, viewH);

    ctx.save();

    // Camera transform with screen shake
    const shakeX = (Math.random() - 0.5) * camera.shake;
    const shakeY = (Math.random() - 0.5) * camera.shake;
    ctx.translate(viewW / 2 + shakeX, viewH / 2 + shakeY);
    ctx.scale(camera.zoom, camera.zoom);
    ctx.translate(-camera.x, -camera.y);

    // Viewport bounds for culling
    const halfW = viewW / (2 * camera.zoom) + 120;
    const halfH = viewH / (2 * camera.zoom) + 120;
    const viewLeft = camera.x - halfW;
    const viewRight = camera.x + halfW;
    const viewTop = camera.y - halfH;
    const viewBottom = camera.y + halfH;

    // 1. Draw World Base Terrain & Biomes
    this.drawTerrain(viewLeft, viewRight, viewTop, viewBottom);

    // 2. Draw Massive Connected Road Network
    this.drawMassiveRoadNetwork(viewLeft, viewRight, viewTop, viewBottom);

    // 3. Draw Mission Marker & Target Aura
    if (activeMission) {
      this.drawMissionTarget(activeMission);
    }

    // 4. Draw Ground Particles (dust, ripples)
    this.drawGroundParticles(particles);

    // 5. Draw Sorted Entities (2.5D layering)
    const drawables: Array<{ y: number; draw: () => void }> = [];

    // Buildings
    buildings.forEach((b) => {
      if (b.x + b.w > viewLeft && b.x < viewRight && b.y + b.h > viewTop && b.y < viewBottom) {
        drawables.push({
          y: b.y + b.h,
          draw: () => this.drawBuilding(b),
        });
      }
    });

    // Vehicles
    vehicles.forEach((v) => {
      if (v.x > viewLeft - 90 && v.x < viewRight + 90 && v.y > viewTop - 90 && v.y < viewBottom + 90) {
        drawables.push({
          y: v.y,
          draw: () => this.drawVehicle(v),
        });
      }
    });

    // NPCs
    npcs.forEach((npc) => {
      if (npc.x > viewLeft - 60 && npc.x < viewRight + 60 && npc.y > viewTop - 60 && npc.y < viewBottom + 60) {
        drawables.push({
          y: npc.y,
          draw: () => this.drawNPC(npc),
        });
      }
    });

    // Dacoits (ডাকাত দল)
    dacoits.forEach((d) => {
      if (d.x > viewLeft - 60 && d.x < viewRight + 60 && d.y > viewTop - 60 && d.y < viewBottom + 60) {
        drawables.push({
          y: d.y,
          draw: () => this.drawDacoit(d),
        });
      }
    });

    // Police Officer
    if (policeOfficer.x > viewLeft - 60 && policeOfficer.x < viewRight + 60 && policeOfficer.y > viewTop - 60 && policeOfficer.y < viewBottom + 60) {
      drawables.push({
        y: policeOfficer.y,
        draw: () => this.drawPolice(policeOfficer),
      });
    }

    // Player (if not in vehicle)
    if (!player.currentVehicleId) {
      drawables.push({
        y: player.y,
        draw: () => this.drawPlayer(player),
      });
    }

    // Sort by Y and draw
    drawables.sort((a, b) => a.y - b.y);
    drawables.forEach((item) => item.draw());

    // 6. Draw Overhead Trees
    this.drawOverheadTrees(viewLeft, viewRight, viewTop, viewBottom);

    // 7. Draw Air Particles (smoke, sparks, fireflies)
    this.drawAirParticles(particles);

    // 8. Day / Night Lighting & Headlights
    this.drawDayNightOverlay(viewLeft, viewRight, viewTop, viewBottom, timeOfDay, vehicles, player, dacoits);

    ctx.restore();

    // 9. On-Screen Compass Arrow towards active mission
    if (activeMission) {
      this.drawOnScreenCompass(viewW, viewH, player, activeMission, camera);
    }

    // 10. Weather Effects (Rain)
    if (weather === "rain" || weather === "thunder") {
      this.drawRainScreen(viewW, viewH, weather);
    }
  }

  // --- Terrain Drawing ---
  private drawTerrain(left: number, right: number, top: number, bottom: number) {
    const ctx = this.ctx;

    // Lush Bengali grass
    ctx.fillStyle = "#3f7a40";
    ctx.fillRect(Math.max(0, left), Math.max(0, top), Math.min(WORLD_WIDTH, right) - Math.max(0, left), Math.min(WORLD_HEIGHT, bottom) - Math.max(0, top));

    // Paddy Fields
    ctx.fillStyle = "#4d9047";
    ctx.fillRect(200, 850, 950, 650);
    // Irrigation canal
    ctx.fillStyle = "#0284c7";
    ctx.fillRect(550, 850, 45, 650);

    // School Football ground
    ctx.fillStyle = "#8a5840";
    ctx.fillRect(1200, 1550, 750, 550);
    ctx.strokeStyle = "rgba(255,255,255,0.7)";
    ctx.lineWidth = 3;
    ctx.strokeRect(1250, 1600, 650, 450);
    ctx.beginPath();
    ctx.arc(1575, 1825, 50, 0, Math.PI * 2);
    ctx.stroke();

    // Village Ponds
    ctx.fillStyle = "#0369a1";
    ctx.beginPath();
    ctx.ellipse(870, 680, 100, 70, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#166534";
    ctx.lineWidth = 6;
    ctx.stroke();

    // Sacred Banyan Pond
    ctx.fillStyle = "#075985";
    ctx.beginPath();
    ctx.ellipse(2300, 2500, 140, 95, 0, 0, Math.PI * 2);
    ctx.fill();

    // Padma River (flows centrally between village and district city)
    const riverW = 700;
    ctx.fillStyle = "#0284c7";
    ctx.fillRect(RIVER_X, 0, riverW, WORLD_HEIGHT);

    // River animated waves
    ctx.strokeStyle = "rgba(255, 255, 255, 0.35)";
    ctx.lineWidth = 2;
    const waveOffset = (this.animTimer * 22) % 60;
    for (let wy = top - (top % 60); wy < bottom + 60; wy += 50) {
      ctx.beginPath();
      const waveX = RIVER_X + 80 + Math.sin(wy * 0.05 + this.animTimer) * 22;
      ctx.moveTo(waveX, wy + waveOffset);
      ctx.bezierCurveTo(waveX + 60, wy + waveOffset - 10, waveX + 120, wy + waveOffset + 10, waveX + 180, wy + waveOffset);
      ctx.stroke();
    }

    // Sandy Shore on village bank
    ctx.fillStyle = "#e2b86a";
    ctx.fillRect(RIVER_X - 60, 0, 60, WORLD_HEIGHT);
    // Sandy Shore on city bank
    ctx.fillRect(RIVER_X + riverW, 0, 60, WORLD_HEIGHT);

    // --- District City Urban Ground & Pavements (East of Padma River) ---
    const cityStartX = RIVER_X + riverW + 60;
    ctx.fillStyle = "#1e293b"; // Urban slate asphalt
    ctx.fillRect(cityStartX, 0, WORLD_WIDTH - cityStartX, WORLD_HEIGHT);

    // City Commercial Plaza Tiles
    ctx.fillStyle = "#334155";
    ctx.fillRect(cityStartX + 100, 450, 1800, 2700);
  }

  // --- Massive Connected Road Network ---
  private drawMassiveRoadNetwork(left: number, right: number, top: number, bottom: number) {
    const ctx = this.ctx;
    const riverW = 700;

    // 1. Long Paved Highway (East-West across entire map connecting village to city!)
    ctx.fillStyle = "#3f3f46"; // Asphalt
    ctx.fillRect(0, 1540, WORLD_WIDTH, 110);

    // Grand Padma Concrete Highway Bridge Crossing the River
    ctx.fillStyle = "#64748b"; // Concrete bridge structure
    ctx.fillRect(RIVER_X - 40, 1530, riverW + 80, 130);
    ctx.fillStyle = "#334155"; // Bridge roadway
    ctx.fillRect(RIVER_X - 40, 1540, riverW + 80, 110);

    // Bridge Concrete Guardrails
    ctx.fillStyle = "#e2e8f0";
    ctx.fillRect(RIVER_X - 40, 1535, riverW + 80, 5);
    ctx.fillRect(RIVER_X - 40, 1650, riverW + 80, 5);

    // Highway Shoulder Gravel
    ctx.fillStyle = "#71717a";
    ctx.fillRect(0, 1532, RIVER_X - 60, 8);
    ctx.fillRect(0, 1650, RIVER_X - 60, 8);

    // Dashed Yellow Centerline
    ctx.strokeStyle = "#facc15";
    ctx.lineWidth = 4;
    ctx.setLineDash([30, 25]);
    ctx.beginPath();
    ctx.moveTo(0, 1595);
    ctx.lineTo(WORLD_WIDTH, 1595);
    ctx.stroke();
    ctx.setLineDash([]);

    // 2. North-South Paved District Road (Village Bypass)
    ctx.fillStyle = "#4b5563";
    ctx.fillRect(2050, 0, 90, WORLD_HEIGHT);
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3;
    ctx.setLineDash([20, 20]);
    ctx.beginPath();
    ctx.moveTo(2095, 0);
    ctx.lineTo(2095, WORLD_HEIGHT);
    ctx.stroke();
    ctx.setLineDash([]);

    // 3. Dense Village Mud Roads & Ring Roads (মেঠো পথ)
    ctx.fillStyle = "#b48c59"; // Rich clay soil
    // Main Village Spine (North-South)
    ctx.fillRect(1000, 100, 80, 2700);
    // Bazaar Crossroad
    ctx.fillRect(100, 960, 2600, 80);
    // Northern Residential Lane
    ctx.fillRect(400, 480, 2350, 75);
    // Southern Mosque & Farm Road
    ctx.fillRect(150, 2200, 2500, 75);
    // River Ghat Embankment Road
    ctx.fillRect(RIVER_X - 140, 200, 80, 2400);

    // Connecting Diagonal / Branch Paths
    ctx.fillRect(350, 480, 75, 560);
    ctx.fillRect(1700, 480, 75, 560);
    ctx.fillRect(1500, 1540, 75, 740);

    // 4. District City Modern Avenue Grid (শহরের পাকা ৪ লেনের এভিনিউ)
    const cityRoadX = RIVER_X + riverW + 60;
    ctx.fillStyle = "#1e293b"; // Smooth city asphalt

    // City Avenue 1 (City Center): y: 680, w: 100
    ctx.fillRect(cityRoadX, 680, WORLD_WIDTH - cityRoadX, 100);
    // City Avenue 2 (Commercial Supermarket): y: 1950, w: 100
    ctx.fillRect(cityRoadX, 1950, WORLD_WIDTH - cityRoadX, 100);
    // City Avenue 3 (Police & Hospital): y: 3220, w: 100
    ctx.fillRect(cityRoadX, 3220, WORLD_WIDTH - cityRoadX, 100);

    // City North-South Boulevards: x: 3850, x: 4450, x: 5050
    ctx.fillRect(3850, 200, 90, 3900);
    ctx.fillRect(4450, 200, 90, 3900);
    ctx.fillRect(5050, 200, 90, 3900);

    // White Lane Markings for City Avenues
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3;
    ctx.setLineDash([25, 20]);
    [730, 2000, 3270].forEach((yPos) => {
      ctx.beginPath();
      ctx.moveTo(cityRoadX, yPos);
      ctx.lineTo(WORLD_WIDTH, yPos);
      ctx.stroke();
    });
    ctx.setLineDash([]);

    // Pedestrian Zebra Crossings in District City
    ctx.fillStyle = "#ffffff";
    [3850, 4450, 5050].forEach((xPos) => {
      [680, 1540, 1950, 3220].forEach((yPos) => {
        for (let i = 0; i < 6; i++) {
          ctx.fillRect(xPos + 10 + i * 12, yPos + 5, 8, 30);
          ctx.fillRect(xPos + 10 + i * 12, yPos + 65, 8, 30);
        }
      });
    });

    // 5. Railway Tracks
    ctx.fillStyle = "#52525b";
    ctx.fillRect(1950, 0, 40, WORLD_HEIGHT);
    ctx.fillStyle = "#451a03"; // Sleepers
    for (let ry = 0; ry < WORLD_HEIGHT; ry += 24) {
      ctx.fillRect(1945, ry, 50, 8);
    }
    ctx.fillStyle = "#e4e4e7"; // Steel rails
    ctx.fillRect(1955, 0, 5, WORLD_HEIGHT);
    ctx.fillRect(1980, 0, 5, WORLD_HEIGHT);

    // 6. Wooden Canal Bridges
    ctx.fillStyle = "#78350f";
    ctx.fillRect(530, 955, 85, 90); // Bridge over canal
    ctx.strokeStyle = "#451a03";
    ctx.lineWidth = 4;
    ctx.strokeRect(530, 955, 85, 90);

    // 7. River Wooden Jetties / Ghats
    ctx.fillStyle = "#78350f";
    ctx.fillRect(RIVER_X - 80, 430, 150, 50);
    ctx.fillRect(RIVER_X - 80, 1180, 130, 45);
    ctx.fillRect(RIVER_X + riverW - 70, 430, 150, 50);
  }

  // --- Buildings ---
  private drawBuilding(b: Building) {
    const ctx = this.ctx;

    // Building Shadow
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(b.x + 8, b.y + b.h - 5, b.w + 10, 18);

    // Main Wall Base
    ctx.fillStyle = b.wallColor || "#a16207";
    ctx.fillRect(b.x, b.y + 20, b.w, b.h - 20);

    // Building Roof
    ctx.fillStyle = b.roofColor || "#64748b";
    ctx.fillRect(b.x - 4, b.y, b.w + 8, b.h * 0.65);

    // Corrugated tin ridges
    ctx.strokeStyle = "rgba(0,0,0,0.2)";
    ctx.lineWidth = 2;
    for (let rx = b.x; rx < b.x + b.w; rx += 14) {
      ctx.beginPath();
      ctx.moveTo(rx, b.y);
      ctx.lineTo(rx, b.y + b.h * 0.65);
      ctx.stroke();
    }

    // Doorway
    ctx.fillStyle = "#331800";
    const doorW = 22;
    const doorH = 34;
    ctx.fillRect(b.x + b.w / 2 - doorW / 2, b.y + b.h - doorH, doorW, doorH);

    // Windows
    ctx.fillStyle = "#0284c7";
    ctx.fillRect(b.x + 12, b.y + b.h - 30, 16, 16);
    ctx.fillRect(b.x + b.w - 28, b.y + b.h - 30, 16, 16);

    // Special signs
    if (b.type === "tea_stall") {
      ctx.fillStyle = "#e2e8f0";
      ctx.fillRect(b.x + b.w / 2 - 8, b.y + b.h - 26, 16, 10);
      // Steam
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.beginPath();
      ctx.arc(b.x + b.w / 2, b.y + b.h - 30 - ((this.animTimer * 20) % 15), 4, 0, Math.PI * 2);
      ctx.fill();
    } else if (b.type === "mosque") {
      ctx.fillStyle = "#047857";
      ctx.beginPath();
      ctx.arc(b.x + b.w / 2, b.y + 10, 36, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = "#facc15";
      ctx.beginPath();
      ctx.arc(b.x + b.w / 2, b.y - 28, 7, 0, Math.PI * 2);
      ctx.fill();
    }

    // Signboard
    ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
    ctx.fillRect(b.x + b.w / 2 - 55, b.y - 18, 110, 18);
    ctx.fillStyle = "#fef08a";
    ctx.font = "bold 10px 'Hind Siliguri', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(b.nameBn, b.x + b.w / 2, b.y - 5);
  }

  // --- Vehicles ---
  private drawVehicle(v: Vehicle) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(v.x, v.y);
    ctx.rotate(v.angle);

    // Shadow
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.fillRect(-v.length / 2 + 3, -v.width / 2 + 5, v.length, v.width);

    if (v.type === "bicycle") {
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(-14, 0, 7, 0, Math.PI * 2);
      ctx.arc(14, 0, 7, 0, Math.PI * 2);
      ctx.stroke();
      ctx.strokeStyle = v.color;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(-14, 0);
      ctx.lineTo(0, -2);
      ctx.lineTo(14, 0);
      ctx.stroke();
    } else if (v.type === "rickshaw") {
      // Driver seat
      ctx.fillStyle = "#000000";
      ctx.fillRect(14, -3, 8, 6);
      // Large rear wheels
      ctx.fillStyle = "#1e293b";
      ctx.fillRect(-10, -v.width / 2 - 2, 14, 4);
      ctx.fillRect(-10, v.width / 2 - 2, 14, 4);
      // Colorful Passenger Hood
      ctx.fillStyle = "#e11d48";
      ctx.fillRect(-v.length / 2, -v.width / 2 + 2, 18, v.width - 4);
      // Painted backplate
      ctx.fillStyle = "#facc15";
      ctx.fillRect(-v.length / 2 - 3, -v.width / 2 + 3, 4, v.width - 6);
      // Driver platform
      ctx.fillStyle = "#78350f";
      ctx.fillRect(0, -6, 12, 12);
    } else if (v.type === "cng") {
      ctx.fillStyle = "#16a34a";
      ctx.fillRect(-v.length / 2, -v.width / 2, v.length, v.width);
      ctx.fillStyle = "#facc15";
      ctx.fillRect(-v.length / 2 + 5, -v.width / 2 + 2, v.length - 12, v.width - 4);
      ctx.fillStyle = "#38bdf8";
      ctx.fillRect(v.length / 2 - 8, -v.width / 2 + 3, 6, v.width - 6);
    } else if (v.type === "tractor") {
      ctx.fillStyle = "#dc2626";
      ctx.fillRect(-v.length / 2 + 8, -v.width / 2 + 4, v.length - 10, v.width - 8);
      ctx.fillStyle = "#09090b";
      ctx.fillRect(-v.length / 2, -v.width / 2 - 3, 18, 7);
      ctx.fillRect(-v.length / 2, v.width / 2 - 4, 18, 7);
      ctx.fillRect(v.length / 2 - 14, -v.width / 2, 10, 5);
      ctx.fillRect(v.length / 2 - 14, v.width / 2 - 5, 10, 5);
    } else if (v.type === "bus") {
      ctx.fillStyle = "#ea580c";
      ctx.fillRect(-v.length / 2, -v.width / 2, v.length, v.width);
      ctx.fillStyle = "#f8fafc";
      ctx.fillRect(-v.length / 2 + 10, -v.width / 2 + 3, v.length - 20, v.width - 6);
      ctx.fillStyle = "#0284c7";
      ctx.fillRect(v.length / 2 - 8, -v.width / 2 + 4, 6, v.width - 8);
    } else if (v.type === "fishing_boat" || v.type === "motorboat") {
      ctx.fillStyle = v.color || "#78350f";
      ctx.beginPath();
      ctx.ellipse(0, 0, v.length / 2, v.width / 2, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = v.color || "#3b82f6";
      ctx.fillRect(-v.length / 2, -v.width / 2, v.length, v.width);
      ctx.fillStyle = "#38bdf8";
      ctx.fillRect(v.length / 6, -v.width / 2 + 3, 10, v.width - 6);
    }

    ctx.restore();
  }

  // --- Player ---
  private drawPlayer(p: Player) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(p.x, p.y);

    // Shadow
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(0, 8, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    const legOffset = Math.sin(this.animTimer * (p.isRunning ? 16 : 9)) * 5;

    // Lungi
    ctx.fillStyle = "#166534";
    if (p.speed > 0.2) {
      ctx.fillRect(-5 + legOffset, 2, 4, 10);
      ctx.fillRect(1 - legOffset, 2, 4, 10);
    } else {
      ctx.fillRect(-4, 2, 8, 10);
    }

    // Panjabi / Shirt
    ctx.fillStyle = "#f8fafc";
    ctx.fillRect(-7, -10, 14, 14);

    // Attack punch animation!
    if (p.isAttacking) {
      ctx.fillStyle = "#c28859";
      const punchX = p.facing === "right" ? 14 : p.facing === "left" ? -14 : 0;
      const punchY = p.facing === "down" ? 12 : p.facing === "up" ? -12 : -2;
      ctx.beginPath();
      ctx.arc(punchX, punchY, 6, 0, Math.PI * 2);
      ctx.fill();
    }

    // Head
    ctx.fillStyle = "#c28859";
    ctx.beginPath();
    ctx.arc(0, -15, 6, 0, Math.PI * 2);
    ctx.fill();

    // Hair
    ctx.fillStyle = "#0f172a";
    ctx.beginPath();
    ctx.arc(0, -17, 6, Math.PI, 0);
    ctx.fill();

    ctx.restore();
  }

  // --- NPCs ---
  private drawNPC(npc: NPC) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(npc.x, npc.y);

    // 1. Ragdoll / Knocked down state from vehicle collision or heavy punch
    if ((npc.knockdownTimer && npc.knockdownTimer > 0) || npc.state === "knocked_down") {
      ctx.rotate(Math.PI / 2);
      ctx.fillStyle = "#7f1d1d";
      ctx.fillRect(-12, -4, 24, 8);

      // Spinning yellow stars above head
      ctx.fillStyle = "#facc15";
      for (let s = 0; s < 3; s++) {
        const starAngle = this.animTimer * 6 + (s * Math.PI * 2) / 3;
        const sx = Math.cos(starAngle) * 12;
        const sy = -16 + Math.sin(starAngle) * 5;
        ctx.beginPath();
        ctx.arc(sx, sy, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.fillStyle = "#ef4444";
      ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("ধাক্কায় কাত!", 0, -22);
      ctx.restore();
      return;
    }

    // Shadow
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.ellipse(0, 7, 10, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Body
    ctx.fillStyle = npc.clothingColor;
    ctx.fillRect(-6, -8, 12, 13);

    // Head
    ctx.fillStyle = npc.skinTone;
    ctx.beginPath();
    ctx.arc(0, -14, 5.5, 0, Math.PI * 2);
    ctx.fill();

    // Bamboo mathal hat
    if (npc.hasHat) {
      ctx.fillStyle = "#facc15";
      ctx.beginPath();
      ctx.moveTo(0, -22);
      ctx.lineTo(-11, -14);
      ctx.lineTo(11, -14);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#78350f";
      ctx.lineWidth = 1;
      ctx.stroke();
    } else {
      ctx.fillStyle = "#09090b";
      ctx.beginPath();
      ctx.arc(0, -16, 5.5, Math.PI, 0);
      ctx.fill();
    }

    // Earthen water pot (কলসি)
    if (npc.hasPot) {
      ctx.fillStyle = "#c2410c";
      ctx.beginPath();
      ctx.arc(8, -4, 5, 0, Math.PI * 2);
      ctx.fill();
    }

    // Speech Bubble
    if (npc.activeDialog) {
      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#0f172a";
      ctx.lineWidth = 1.5;
      const bubbleW = Math.min(220, npc.activeDialog.length * 9 + 20);
      ctx.beginPath();
      ctx.roundRect(-bubbleW / 2, -55, bubbleW, 26, 6);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "#0f172a";
      ctx.font = "bold 10px 'Hind Siliguri', sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(npc.activeDialog, 0, -38);
    } else {
      ctx.fillStyle = "rgba(15,23,42,0.8)";
      ctx.fillRect(-28, -28, 56, 12);
      ctx.fillStyle = "#fef08a";
      ctx.font = "9px 'Hind Siliguri', sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(npc.nameBn, 0, -19);
    }

    ctx.restore();
  }

  // --- Dacoits (ডাকাত দল) ---
  private drawDacoit(d: Dacoit) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(d.x, d.y);

    if (d.isKnockedOut) {
      // Knocked out on ground
      ctx.fillStyle = "#7f1d1d";
      ctx.fillRect(-12, -4, 24, 8);
      ctx.fillStyle = "#f87171";
      ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
      ctx.fillText("পরাজিত", 0, -8);
      ctx.restore();
      return;
    }

    // Shadow
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(0, 8, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Dark bandit vest & black lungi
    ctx.fillStyle = "#18181b";
    ctx.fillRect(-6, -8, 12, 13);
    // Red bandana / gamcha
    ctx.fillStyle = "#dc2626";
    ctx.fillRect(-6, -11, 12, 3);

    // Head
    ctx.fillStyle = "#945c31";
    ctx.beginPath();
    ctx.arc(0, -15, 6, 0, Math.PI * 2);
    ctx.fill();

    // Wooden Lathi (বাঁশের লাঠি)
    ctx.strokeStyle = "#78350f";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(6, 6);
    ctx.lineTo(14, -20);
    ctx.stroke();

    // Flaming Torch (মশাল) in hand!
    ctx.fillStyle = "#ea580c";
    ctx.beginPath();
    ctx.arc(14, -22, 5 + Math.sin(this.animTimer * 12) * 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#facc15";
    ctx.beginPath();
    ctx.arc(14, -22, 3, 0, Math.PI * 2);
    ctx.fill();

    // Bandit Alert Warning
    ctx.fillStyle = "#ef4444";
    ctx.font = "bold 10px 'Hind Siliguri', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("ডাকাত!", 0, -28);

    ctx.restore();
  }

  // --- Police Officer ---
  private drawPolice(p: PoliceOfficer) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(p.x, p.y);

    // Shadow
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(0, 8, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // Blue Police Uniform
    ctx.fillStyle = "#1e3a8a";
    ctx.fillRect(-6, -8, 12, 13);

    // Police Cap
    ctx.fillStyle = "#172554";
    ctx.fillRect(-6, -18, 12, 4);

    // Head
    ctx.fillStyle = "#c28859";
    ctx.beginPath();
    ctx.arc(0, -14, 5.5, 0, Math.PI * 2);
    ctx.fill();

    // Flashing Siren Light above head
    if (p.isSirenActive) {
      const isRed = Math.floor(this.animTimer * 10) % 2 === 0;
      ctx.fillStyle = isRed ? "#ef4444" : "#3b82f6";
      ctx.beginPath();
      ctx.arc(0, -25, 6, 0, Math.PI * 2);
      ctx.fill();

      // Siren glow ring
      ctx.strokeStyle = isRed ? "rgba(239, 68, 68, 0.4)" : "rgba(59, 130, 246, 0.4)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, -25, 14, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = "#60a5fa";
    ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("পুলিশ", 0, -32);

    ctx.restore();
  }

  // --- Overhead Trees ---
  private drawOverheadTrees(left: number, right: number, top: number, bottom: number) {
    const ctx = this.ctx;
    const trees = [
      { x: 520, y: 350, type: "coconut" },
      { x: 740, y: 360, type: "coconut" },
      { x: 920, y: 440, type: "mango" },
      { x: 1250, y: 340, type: "mango" },
      { x: 1700, y: 380, type: "coconut" },
      { x: 2150, y: 450, type: "mango" },
      { x: 2280, y: 420, type: "coconut" },
      { x: 1100, y: 1450, type: "coconut" },
      { x: 1800, y: 1500, type: "mango" },
      { x: 620, y: 1850, type: "coconut" },
      { x: 1300, y: 2150, type: "mango" },
      { x: 1650, y: 2200, type: "coconut" },
      { x: 2200, y: 2350, type: "banyan" }, // Outlaw banyan tree
    ];

    trees.forEach((t) => {
      if (t.x > left - 120 && t.x < right + 120 && t.y > top - 120 && t.y < bottom + 120) {
        if (t.type === "coconut") {
          ctx.strokeStyle = "#78350f";
          ctx.lineWidth = 8;
          ctx.beginPath();
          ctx.moveTo(t.x, t.y);
          ctx.quadraticCurveTo(t.x + 8, t.y - 40, t.x + 12, t.y - 75);
          ctx.stroke();
          ctx.fillStyle = "#15803d";
          for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
            ctx.beginPath();
            ctx.ellipse(t.x + 12 + Math.cos(a) * 25, t.y - 75 + Math.sin(a) * 20, 24, 7, a, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (t.type === "banyan") {
          ctx.fillStyle = "#14532d";
          ctx.beginPath();
          ctx.arc(t.x, t.y - 80, 85, 0, Math.PI * 2);
          ctx.arc(t.x - 45, t.y - 70, 65, 0, Math.PI * 2);
          ctx.arc(t.x + 45, t.y - 70, 65, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = "#15803d";
          ctx.beginPath();
          ctx.arc(t.x, t.y - 45, 38, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#78350f";
          ctx.fillRect(t.x - 6, t.y - 20, 12, 22);
        }
      }
    });
  }

  // --- Mission Target Zone ---
  private drawMissionTarget(m: Mission) {
    const ctx = this.ctx;
    const target = m.pickupLocation && !m.hasPickedUp ? m.pickupLocation : m.targetLocation;
    const pulse = Math.sin(this.animTimer * 5) * 6;

    ctx.strokeStyle = "#facc15";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(target.x, target.y, m.targetRadius + pulse, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = "rgba(250, 204, 21, 0.25)";
    ctx.beginPath();
    ctx.arc(target.x, target.y, m.targetRadius + pulse, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#ef4444";
    ctx.beginPath();
    ctx.arc(target.x, target.y - 35 + Math.sin(this.animTimer * 4) * 5, 12, 0, Math.PI * 2);
    ctx.fill();
  }

  // --- On-Screen Compass Pointer towards Mission ---
  private drawOnScreenCompass(
    viewW: number,
    viewH: number,
    player: Player,
    mission: Mission,
    camera: { x: number; y: number; zoom: number }
  ) {
    const ctx = this.ctx;
    const target = mission.pickupLocation && !mission.hasPickedUp ? mission.pickupLocation : mission.targetLocation;
    const dx = target.x - player.x;
    const dy = target.y - player.y;
    const dist = Math.hypot(dx, dy);

    // If mission target is off-screen or far away, draw compass arrow at screen edge!
    const angle = Math.atan2(dy, dx);
    const radius = Math.min(viewW, viewH) * 0.42;
    const arrowX = viewW / 2 + Math.cos(angle) * radius;
    const arrowY = viewH / 2 + Math.sin(angle) * radius;

    ctx.save();
    ctx.translate(arrowX, arrowY);
    ctx.rotate(angle);

    // 3D-styled Glowing Pointer
    ctx.fillStyle = "#ef4444";
    ctx.beginPath();
    ctx.moveTo(18, 0);
    ctx.lineTo(-12, -9);
    ctx.lineTo(-6, 0);
    ctx.lineTo(-12, 9);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.restore();

    // Distance Badge
    ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
    ctx.beginPath();
    ctx.roundRect(arrowX - 40, arrowY + 14, 80, 20, 6);
    ctx.fill();
    ctx.fillStyle = "#fef08a";
    ctx.font = "bold 10px 'Hind Siliguri', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(`${Math.round(dist / 10)} মি.`, arrowX, arrowY + 28);
  }

  // --- Particles ---
  private drawGroundParticles(particles: Particle[]) {
    const ctx = this.ctx;
    particles.forEach((p) => {
      if (p.type === "dust" || p.type === "water") {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    ctx.globalAlpha = 1;
  }

  private drawAirParticles(particles: Particle[]) {
    const ctx = this.ctx;
    particles.forEach((p) => {
      if (p.type === "shout" && p.text) {
        ctx.save();
        ctx.globalAlpha = Math.min(1, p.alpha * 1.5);
        ctx.fillStyle = "#ef4444"; // Bold comic alert red
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2.5;
        ctx.font = "bold 13px 'Hind Siliguri', sans-serif";
        const tw = ctx.measureText(p.text).width + 20;
        ctx.beginPath();
        ctx.roundRect(p.x - tw / 2, p.y - 14, tw, 26, 6);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#ffffff";
        ctx.textAlign = "center";
        ctx.fillText(p.text, p.x, p.y + 4);
        ctx.restore();
      } else if (p.type === "firefly" || p.type === "smoke" || p.type === "spark" || p.type === "hit" || p.type === "coin") {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    ctx.globalAlpha = 1;
  }

  // --- Day / Night Overlay ---
  private drawDayNightOverlay(
    left: number,
    right: number,
    top: number,
    bottom: number,
    timeOfDay: TimeOfDay,
    vehicles: Vehicle[],
    player: Player,
    dacoits: Dacoit[]
  ) {
    const ctx = this.ctx;
    if (timeOfDay === "afternoon") return;

    let overlayColor = "";
    if (timeOfDay === "morning") {
      overlayColor = "rgba(254, 240, 138, 0.08)";
    } else if (timeOfDay === "evening") {
      overlayColor = "rgba(249, 115, 22, 0.18)";
    } else if (timeOfDay === "night") {
      overlayColor = "rgba(10, 15, 30, 0.75)"; // Dark night
    }

    ctx.fillStyle = overlayColor;
    ctx.fillRect(left, top, right - left, bottom - top);

    // Night headlights & bandit torches illumination
    if (timeOfDay === "night") {
      vehicles.forEach((v) => {
        if (v.occupied || v.id === player.currentVehicleId) {
          ctx.save();
          ctx.translate(v.x, v.y);
          ctx.rotate(v.angle);
          const grad = ctx.createRadialGradient(25, 0, 5, 130, 0, 80);
          grad.addColorStop(0, "rgba(254, 240, 138, 0.7)");
          grad.addColorStop(1, "rgba(254, 240, 138, 0)");
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.moveTo(10, -5);
          ctx.lineTo(140, -45);
          ctx.lineTo(140, 45);
          ctx.lineTo(10, 5);
          ctx.closePath();
          ctx.fill();
          ctx.restore();
        }
      });
    }
  }

  // --- Rain Screen FX ---
  private drawRainScreen(w: number, h: number, weather: WeatherType) {
    const ctx = this.ctx;
    ctx.strokeStyle = "rgba(203, 213, 225, 0.4)";
    ctx.lineWidth = 1.5;
    const density = weather === "thunder" ? 140 : 80;
    for (let i = 0; i < density; i++) {
      const rx = (Math.sin(i * 99 + this.animTimer * 10) * 0.5 + 0.5) * w;
      const ry = (i * 37 + this.animTimer * 600) % h;
      ctx.beginPath();
      ctx.moveTo(rx, ry);
      ctx.lineTo(rx - 8, ry + 18);
      ctx.stroke();
    }
  }

  // --- Detailed Enterable Shop Interior Scene (দোকানের ভেতরের দৃশ্য) ---
  private drawShopInterior(player: Player, viewW: number, viewH: number) {
    const ctx = this.ctx;
    const interior = player.currentInterior;

    // Dim background
    ctx.fillStyle = "#09090b";
    ctx.fillRect(0, 0, viewW, viewH);

    // Interior Room Dimensions
    const roomW = Math.min(640, viewW - 30);
    const roomH = Math.min(460, viewH - 30);
    const rx = (viewW - roomW) / 2;
    const ry = (viewH - roomH) / 2;

    // Room Wooden Floor
    ctx.fillStyle = "#78350f";
    ctx.fillRect(rx, ry, roomW, roomH);

    // Floor Planks Texture
    ctx.strokeStyle = "rgba(0,0,0,0.2)";
    ctx.lineWidth = 1.5;
    for (let py = ry + 25; py < ry + roomH; py += 30) {
      ctx.beginPath();
      ctx.moveTo(rx, py);
      ctx.lineTo(rx + roomW, py);
      ctx.stroke();
    }

    // Room Back Wall
    const wallH = 100;
    ctx.fillStyle = interior === "police_station" ? "#334155" : interior === "hospital_clinic" ? "#065f46" : "#451a03";
    ctx.fillRect(rx, ry, roomW, wallH);

    // Wall Top Border
    ctx.fillStyle = "#292524";
    ctx.fillRect(rx, ry, roomW, 8);

    // Hanging Bengali Calendar / Frames
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(rx + 60, ry + 20, 36, 48);
    ctx.fillStyle = "#dc2626";
    ctx.fillRect(rx + 64, ry + 24, 28, 14);

    // Window looking outside
    ctx.fillStyle = "#38bdf8";
    ctx.fillRect(rx + roomW - 120, ry + 20, 60, 48);
    ctx.strokeStyle = "#451a03";
    ctx.lineWidth = 3;
    ctx.strokeRect(rx + roomW - 120, ry + 20, 60, 48);

    // Counter Desk & Furniture based on interior type
    const counterY = ry + 160;
    ctx.fillStyle = "#9a3412";
    ctx.fillRect(rx + 80, counterY, roomW - 160, 42);

    // Counter Surface Trim
    ctx.fillStyle = "#ea580c";
    ctx.fillRect(rx + 78, counterY - 4, roomW - 156, 8);

    let titleBn = "";
    let shopkeeperName = "";
    let speechBn = "";

    if (interior === "tea_stall") {
      titleBn = "করিম ভাইয়ের ঐতিহ্যবাহী গ্রামীণ চা স্টল";
      shopkeeperName = "করিম ভাই (চা কারিগর)";
      speechBn = "“খাঁটি গরুর দুধের স্পেশাল মালাই চা খাবেন ভাই? স্বাস্থ্য সম্পূর্ণ ভালো হবে!”";

      // Steaming Kettle on counter
      ctx.fillStyle = "#94a3b8";
      ctx.fillRect(rx + 110, counterY - 24, 28, 22);
      ctx.fillStyle = "#f59e0b";
      ctx.fillRect(rx + 114, counterY - 28, 20, 5);
      // Steam
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      for (let s = 0; s < 3; s++) {
        ctx.beginPath();
        const sy = counterY - 32 - ((this.animTimer * 25 + s * 10) % 20);
        ctx.arc(rx + 124 + s * 4, sy, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // Glass Biscuit Jars
      ctx.fillStyle = "rgba(255,255,255,0.6)";
      ctx.fillRect(rx + 160, counterY - 26, 22, 24);
      ctx.fillStyle = "#d97706";
      ctx.fillRect(rx + 163, counterY - 20, 16, 16); // Biscuits inside
    } else if (interior === "grocery_store") {
      titleBn = "রফিকের পাইকারি ও খুচরা মুদি দোকান";
      shopkeeperName = "মুদি রফিক";
      speechBn = "“তাজা চাল, ডাল, সরিষার তেল ও মসলা সব মজুদ আছে ভাই!”";

      // Rice Sacks
      ctx.fillStyle = "#fef08a";
      ctx.fillRect(rx + 110, counterY - 26, 32, 24);
      ctx.fillStyle = "#ca8a04";
      ctx.fillRect(rx + 150, counterY - 26, 32, 24);
    } else if (interior === "garage_workshop") {
      titleBn = "জব্বার মেকানিক অটো সার্ভিস সেন্টার";
      shopkeeperName = "ওস্তাদ জব্বার মেকানিক";
      speechBn = "“রিকশা, সিএনজি, ট্রাক্টর কিংবা প্রাইভেট কার—যেকোনো গাড়ির কাজ নিখুঁত!”";

      // Tools and Tires
      ctx.fillStyle = "#1e293b";
      ctx.beginPath();
      ctx.arc(rx + 120, counterY - 14, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#e2e8f0";
      ctx.fillRect(rx + 155, counterY - 18, 24, 16);
    } else if (interior === "police_station") {
      titleBn = "জেলা পুলিশ ফাঁড়ি ও আইনি সহায়তা কেন্দ্র";
      shopkeeperName = "ডিউটি অফিসার মিজান";
      speechBn = "“আইনশৃঙ্খলা মেনে চলুন। ডাকাত বা গুন্ডাদের উৎপাত হলে দ্রুত জানান!”";

      // Jail Bars on side
      ctx.strokeStyle = "#94a3b8";
      ctx.lineWidth = 4;
      for (let jx = rx + roomW - 140; jx < rx + roomW - 40; jx += 16) {
        ctx.beginPath();
        ctx.moveTo(jx, ry + 10);
        ctx.lineTo(jx, ry + roomH - 60);
        ctx.stroke();
      }
    } else if (interior === "hospital_clinic") {
      titleBn = "পল্লী স্বাস্থ্য সেবা কেন্দ্র ও ক্লিনিক";
      shopkeeperName = "ডাঃ শফিক আহমেদ";
      speechBn = "“প্রাথমিক চিকিৎসা নিন ও পূর্ণ বিশ্রাম করুন। স্বাস্থ্য অমূল্য সম্পদ!”";

      // Hospital Bed
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(rx + 100, counterY - 25, 60, 24);
      ctx.fillStyle = "#38bdf8";
      ctx.fillRect(rx + 105, counterY - 22, 16, 18);
    } else {
      titleBn = "জেলা আধুনিক ডিপার্টমেন্টাল সুপারমার্কেট";
      shopkeeperName = "সুপারশপ ম্যানেজার";
      speechBn = "“স্বাগতম! সব আধুনিক খাদ্যপণ্য ও গৃহস্থালি সামগ্রী এখানে পাবেন!”";
    }

    // Shopkeeper Avatar behind counter
    ctx.fillStyle = "#15803d";
    ctx.fillRect(rx + roomW / 2 - 12, counterY - 45, 24, 28);
    ctx.fillStyle = "#c28859";
    ctx.beginPath();
    ctx.arc(rx + roomW / 2, counterY - 55, 10, 0, Math.PI * 2);
    ctx.fill();

    // Top Sign Banner
    ctx.fillStyle = "rgba(15, 23, 42, 0.95)";
    ctx.fillRect(rx + 20, ry + 12, roomW - 40, 32);
    ctx.fillStyle = "#fef08a";
    ctx.font = "bold 15px 'Hind Siliguri', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(titleBn, rx + roomW / 2, ry + 34);

    // Dialogue Banner
    ctx.fillStyle = "rgba(30, 41, 59, 0.9)";
    ctx.fillRect(rx + 40, counterY + 60, roomW - 80, 40);
    ctx.fillStyle = "#38bdf8";
    ctx.font = "bold 11px 'Hind Siliguri', sans-serif";
    ctx.fillText(shopkeeperName, rx + roomW / 2, counterY + 76);
    ctx.fillStyle = "#ffffff";
    ctx.font = "12px 'Hind Siliguri', sans-serif";
    ctx.fillText(speechBn, rx + roomW / 2, counterY + 92);

    // Player Avatar inside room
    const playerInteriorX = rx + roomW / 2;
    const playerInteriorY = counterY + 160;
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.beginPath();
    ctx.ellipse(playerInteriorX, playerInteriorY + 12, 14, 7, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#166534";
    ctx.fillRect(playerInteriorX - 6, playerInteriorY, 12, 12);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(playerInteriorX - 8, playerInteriorY - 14, 16, 14);
    ctx.fillStyle = "#c28859";
    ctx.beginPath();
    ctx.arc(playerInteriorX, playerInteriorY - 20, 8, 0, Math.PI * 2);
    ctx.fill();

    // Exit Door Mat at Bottom
    ctx.fillStyle = "#10b981";
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    const matW = 140;
    const matH = 34;
    const matX = rx + roomW / 2 - matW / 2;
    const matY = ry + roomH - matH - 12;
    ctx.beginPath();
    ctx.roundRect(matX, matY, matW, matH, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "#022c22";
    ctx.font = "bold 13px 'Hind Siliguri', sans-serif";
    ctx.fillText("🚪 বাহিরে যান (E) / EXIT", rx + roomW / 2, matY + 22);
  }
}
