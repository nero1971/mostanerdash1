import { soundManager } from "../audio/SoundManager";
import {
  Building,
  Dacoit,
  GameSettings,
  GameState,
  Mission,
  NPC,
  Particle,
  Player,
  PoliceOfficer,
  TimeOfDay,
  Vehicle,
  WeatherType,
} from "../types/game";
import {
  BUILDINGS,
  INITIAL_NPCS,
  INITIAL_VEHICLES,
  MISSIONS,
  REGIONS,
  RIVER_X,
  WORLD_HEIGHT,
  WORLD_WIDTH,
  BENGALI_HIT_SCREAMS,
} from "./constants";
import { GameRenderer } from "./renderer";

const SAVE_KEY = "amader_gram_bangla_save_v2";

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private renderer: GameRenderer;

  public state: GameState = "INTRO_MODAL"; // Show "বাপের রাস্তা" intro modal first!
  public player: Player;
  public vehicles: Vehicle[] = [];
  public npcs: NPC[] = [];
  public dacoits: Dacoit[] = [];
  public policeOfficer: PoliceOfficer;
  public buildings: Building[] = [];
  public particles: Particle[] = [];

  public activeMission: Mission | null = null;
  public activeMissionIndex = 0;
  public completedMissions: number[] = [];
  public missionTimer: number | null = null;

  public camera = { x: 650, y: 460, zoom: 1.0, shake: 0 };
  public timeOfDay: TimeOfDay = "morning";
  public weather: WeatherType = "clear";
  private timeCycleTimer = 0;

  public settings: GameSettings = {
    language: "bn",
    graphicsQuality: "high",
    controlType: "dpad", // D-Pad default for immediate responsiveness on mobile!
    controlSize: "medium",
    leftHanded: false,
    showMinimap: true,
    sound: {
      master: 0.8,
      music: 0.6,
      ambient: 0.5,
      vehicles: 0.7,
      sfx: 0.8,
      muted: false,
    },
  };

  // Inputs
  public inputs = {
    up: false,
    down: false,
    left: false,
    right: false,
    run: false,
    action: false,
    attack: false,
    horn: false,
    justPressedAction: false,
    justPressedAttack: false,
    justPressedHorn: false,
  };

  public joystick = { x: 0, y: 0, active: false };

  private isRunning = false;
  private lastTime = 0;
  private animationFrameId: number | null = null;
  private stepDistance = 0;

  public notification: { title: string; desc: string; timer: number } | null = null;

  public onStateChange?: (state: GameState) => void;
  public onHudUpdate?: () => void;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) throw new Error("Could not get 2D context");
    this.ctx = context;
    this.renderer = new GameRenderer(this.ctx);

    // Initial player state at Radhanagar Starting Home with smooth walking
    this.player = {
      x: 650,
      y: 460,
      angle: 0,
      speed: 0,
      walkSpeed: 2.6, // Smooth, natural walking pace
      runSpeed: 4.8,  // Controllable sprint pace
      health: 100,
      maxHealth: 100,
      money: 200,
      currentVehicleId: null,
      currentInterior: null,
      isRunning: false,
      isInteracting: false,
      isAttacking: false,
      attackTimer: 0,
      facing: "down",
      animFrame: 0,
      wantedLevel: 0,
      finesDue: 0,
      weapon: "fist",
    };

    this.policeOfficer = {
      id: "police_mizan",
      nameBn: "অফিসার মিজান",
      x: 2180,
      y: 1610,
      targetX: 2180,
      targetY: 1610,
      speed: 3.5,
      isSirenActive: false,
      sirenTimer: 0,
      chasingDacoitId: null,
    };

    this.buildings = [...BUILDINGS];
    this.vehicles = JSON.parse(JSON.stringify(INITIAL_VEHICLES));
    this.npcs = JSON.parse(JSON.stringify(INITIAL_NPCS)).map((n: NPC) => ({
      ...n,
      knockbackVx: 0,
      knockbackVy: 0,
      knockdownTimer: 0,
    }));

    // Initialize initial Dacoits near Banyan Tree
    this.dacoits = [
      {
        id: "dacoit_1",
        nameBn: "ডাকাত কালু",
        x: 2120,
        y: 2320,
        targetX: 2120,
        targetY: 2320,
        speed: 3.2,
        health: 70,
        maxHealth: 70,
        isChasing: false,
        attackCooldown: 0,
        hasLoot: true,
        isKnockedOut: false,
        knockbackVx: 0,
        knockbackVy: 0,
        knockdownTimer: 0,
      },
      {
        id: "dacoit_2",
        nameBn: "ডাকাত জলিল",
        x: 2200,
        y: 2380,
        targetX: 2200,
        targetY: 2380,
        speed: 3.4,
        health: 80,
        maxHealth: 80,
        isChasing: false,
        attackCooldown: 0,
        hasLoot: true,
        isKnockedOut: false,
        knockbackVx: 0,
        knockbackVy: 0,
        knockdownTimer: 0,
      },
      {
        id: "dacoit_3",
        nameBn: "ডাকাত সর্দার বাচ্চু",
        x: 2160,
        y: 2420,
        targetX: 2160,
        targetY: 2420,
        speed: 3.0,
        health: 100,
        maxHealth: 100,
        isChasing: false,
        attackCooldown: 0,
        hasLoot: true,
        isKnockedOut: false,
        knockbackVx: 0,
        knockbackVy: 0,
        knockdownTimer: 0,
      },
    ];

    this.loadProgress();
    this.setupListeners();

    // Start with Mission 1 ready
    if (this.completedMissions.length === 0) {
      this.activeMission = { ...MISSIONS[0], hasPickedUp: false };
    }
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.lastTime = performance.now();
    soundManager.init();
    soundManager.updateVolumes(this.settings.sound);

    const loop = (time: number) => {
      const rawDt = (time - this.lastTime) / 1000;
      this.lastTime = time;
      const dt = Math.min(rawDt, 0.05);

      this.update(dt);
      this.render(dt);

      this.inputs.justPressedAction = false;
      this.inputs.justPressedAttack = false;
      this.inputs.justPressedHorn = false;

      if (this.isRunning) {
        this.animationFrameId = requestAnimationFrame(loop);
      }
    };

    this.animationFrameId = requestAnimationFrame(loop);
  }

  public stop() {
    this.isRunning = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    soundManager.stopEngine();
    soundManager.stopRadio();
  }

  private setupListeners() {
    window.addEventListener("keydown", (e) => {
      if (e.repeat) return;
      soundManager.resume();

      switch (e.code) {
        case "KeyW":
        case "ArrowUp":
          this.inputs.up = true;
          break;
        case "KeyS":
        case "ArrowDown":
          this.inputs.down = true;
          break;
        case "KeyA":
        case "ArrowLeft":
          this.inputs.left = true;
          break;
        case "KeyD":
        case "ArrowRight":
          this.inputs.right = true;
          break;
        case "ShiftLeft":
        case "ShiftRight":
          this.inputs.run = true;
          break;
        case "KeyE":
          this.inputs.action = true;
          this.inputs.justPressedAction = true;
          this.handleActionPress();
          break;
        case "KeyF":
          this.inputs.attack = true;
          this.inputs.justPressedAttack = true;
          this.handleAttack();
          break;
        case "Space":
          this.inputs.horn = true;
          this.inputs.justPressedHorn = true;
          this.handleHornPress();
          break;
        case "Escape":
          if (this.state === "PLAYING") {
            this.setState("PAUSED");
          } else if (this.state === "PAUSED") {
            this.setState("PLAYING");
          }
          break;
      }
    });

    window.addEventListener("keyup", (e) => {
      switch (e.code) {
        case "KeyW":
        case "ArrowUp":
          this.inputs.up = false;
          break;
        case "KeyS":
        case "ArrowDown":
          this.inputs.down = false;
          break;
        case "KeyA":
        case "ArrowLeft":
          this.inputs.left = false;
          break;
        case "KeyD":
        case "ArrowRight":
          this.inputs.right = false;
          break;
        case "ShiftLeft":
        case "ShiftRight":
          this.inputs.run = false;
          break;
        case "KeyE":
          this.inputs.action = false;
          break;
        case "KeyF":
          this.inputs.attack = false;
          break;
        case "Space":
          this.inputs.horn = false;
          break;
      }
    });

    window.addEventListener("blur", () => {
      this.inputs = {
        up: false,
        down: false,
        left: false,
        right: false,
        run: false,
        action: false,
        attack: false,
        horn: false,
        justPressedAction: false,
        justPressedAttack: false,
        justPressedHorn: false,
      };
      this.joystick = { x: 0, y: 0, active: false };
    });
  }

  // --- Attack / Fight Bandits & Hostile Thugs ---
  public handleAttack() {
    if (this.state !== "PLAYING") return;
    this.player.isAttacking = true;
    this.player.attackTimer = 0.25;
    soundManager.playPunch();

    // 1. Check hit against nearby dacoits
    this.dacoits.forEach((d) => {
      if (d.isKnockedOut) return;
      const dist = Math.hypot(d.x - this.player.x, d.y - this.player.y);
      if (dist < 65) {
        d.health = Math.max(0, d.health - 35);
        this.camera.shake = 8;
        soundManager.playBodyHit();

        this.addParticle({
          x: d.x,
          y: d.y,
          vx: (Math.random() - 0.5) * 8,
          vy: (Math.random() - 0.5) * 8,
          size: 5,
          color: "#f87171",
          alpha: 0.9,
          life: 0.35,
          maxLife: 0.35,
          type: "hit",
        });

        if (d.health <= 0) {
          d.isKnockedOut = true;
          this.player.money += 100;
          soundManager.playCoin();
          this.showToast("ডাকাত পরাস্ত!", "ডাকাত পরাজিত হয়েছে! আপনি ৳১০০ উদ্ধার করেছেন!");
        } else {
          this.showToast("ঘুষি!", `ডাকাত আঘাত পেয়েছে! (স্বাস্থ্য: ${d.health})`);
        }
      }
    });

    // 2. Check hit against hostile thugs/gangsters (মাস্তান ও গুন্ডা বাহিনী)
    this.npcs.forEach((n) => {
      if (!n.isHostile || n.state === "knocked_down") return;
      const dist = Math.hypot(n.x - this.player.x, n.y - this.player.y);
      if (dist < 70) {
        n.health = Math.max(0, (n.health || 100) - 40);
        n.knockbackVx = Math.sign(n.x - this.player.x) * 8;
        n.knockbackVy = Math.sign(n.y - this.player.y) * 8;
        n.knockdownTimer = 2.0;
        n.state = "knocked_down";
        this.camera.shake = 10;
        soundManager.playBodyHit();

        this.addParticle({
          type: "shout",
          text: "আরে মাইরে ফেলছে রে!",
          x: n.x,
          y: n.y - 20,
          vx: n.knockbackVx * 0.3,
          vy: -2,
          size: 8,
          color: "#ef4444",
          alpha: 1,
          life: 2.0,
          maxLife: 2.0,
        });

        if (n.health <= 0) {
          n.isHostile = false;
          this.player.money += 200;
          soundManager.playCoin();
          this.showToast("মাস্তান দমন!", `${n.nameBn} পরাস্ত হয়েছে! ৳২০০ উদ্ধার হয়েছে!`);
        } else {
          this.showToast("ঘুষি!", `${n.nameBn} আঘাত খেয়েছে! (স্বাস্থ্য: ${n.health})`);
        }
      }
    });

    if (this.onHudUpdate) this.onHudUpdate();
  }

  // --- Emergency Police Call ---
  public callPolice() {
    soundManager.playSiren();
    this.policeOfficer.isSirenActive = true;
    this.policeOfficer.sirenTimer = 15;
    // Spawn police near player to rescue
    this.policeOfficer.x = this.player.x - 120;
    this.policeOfficer.y = this.player.y;
    this.policeOfficer.targetX = this.player.x;
    this.policeOfficer.targetY = this.player.y;

    // Frighten and arrest nearby dacoits
    this.dacoits.forEach((d) => {
      if (Math.hypot(d.x - this.player.x, d.y - this.player.y) < 300) {
        d.isChasing = false;
        d.isKnockedOut = true;
      }
    });

    this.showToast("পুলিশ এসেছে!", "অফিসার মিজান সাইরেন বাজিয়ে উপস্থিত হয়েছেন! ডাকাতরা গ্রেপ্তার হয়েছে!");
    if (this.onHudUpdate) this.onHudUpdate();
  }

  // --- Action Press (Vehicle / Shop Entry / Dialog) ---
  public handleActionPress() {
    if (this.state !== "PLAYING") return;

    // 1. If currently inside a shop, pressing Action exits back outside
    if (this.player.currentInterior) {
      soundManager.playShopDoorBell();
      this.player.currentInterior = null;
      this.showToast("দোকান থেকে প্রস্থান", "আপনি আবার উন্মুক্ত রাস্তায় ফিরে এসেছেন।");
      if (this.onHudUpdate) this.onHudUpdate();
      return;
    }

    // 2. If in vehicle, exit vehicle
    if (this.player.currentVehicleId) {
      this.exitVehicle();
      return;
    }

    // 3. Check enterable shop door proximity
    const nearbyBuilding = this.buildings.find((b) => {
      if (!b.isEnterable) return false;
      const dX = b.doorX || (b.x + b.w / 2);
      const dY = b.doorY || (b.y + b.h);
      return Math.hypot(dX - this.player.x, dY - this.player.y) < 75;
    });

    if (nearbyBuilding) {
      this.player.currentInterior = nearbyBuilding.interiorType || "tea_stall";
      soundManager.playShopDoorBell();
      if (this.player.currentInterior === "tea_stall" || this.player.currentInterior === "hospital_clinic") {
        this.player.health = Math.min(this.player.maxHealth, this.player.health + 30);
      }
      this.showToast(nearbyBuilding.nameBn, "দোকানে প্রবেশ করেছেন! (পুনরায় অ্যাকশন বাটন চাপলে বাইরে বের হবেন)");
      if (this.onHudUpdate) this.onHudUpdate();
      return;
    }

    // 4. Check vehicle entry proximity
    const nearbyVeh = this.vehicles.find((v) => {
      const dist = Math.hypot(v.x - this.player.x, v.y - this.player.y);
      return dist < 85 && !v.occupied;
    });

    if (nearbyVeh) {
      this.enterVehicle(nearbyVeh);
      return;
    }

    // 5. Check NPC talking proximity
    const nearbyNPC = this.npcs.find((n) => {
      return Math.hypot(n.x - this.player.x, n.y - this.player.y) < 85;
    });

    if (nearbyNPC) {
      const phrases = this.settings.language === "bn" ? nearbyNPC.speechBn : nearbyNPC.speechEn;
      nearbyNPC.activeDialog = phrases[Math.floor(Math.random() * phrases.length)];
      nearbyNPC.dialogTimer = 4.5;
      soundManager.playPhoneBeep();
      this.showToast(nearbyNPC.nameBn, nearbyNPC.activeDialog);
    }
  }

  public handleHornPress() {
    if (this.state !== "PLAYING") return;
    if (this.player.currentVehicleId) {
      const veh = this.vehicles.find((v) => v.id === this.player.currentVehicleId);
      if (veh) {
        soundManager.playHorn(veh.type);
        this.npcs.forEach((npc) => {
          if (Math.hypot(npc.x - veh.x, npc.y - veh.y) < 180) {
            npc.targetX += Math.sign(npc.x - veh.x) * 50;
            npc.targetY += Math.sign(npc.y - veh.y) * 50;
          }
        });
      }
    } else {
      soundManager.playBicycleBell();
    }
  }

  public enterVehicle(v: Vehicle) {
    if (v.isWaterVehicle && this.player.x < RIVER_X - 100) {
      this.showToast("নৌকা", "নৌকা চালাতে হলে পদ্মা নদীর ঘাটে যান!");
      return;
    }
    this.player.currentVehicleId = v.id;
    v.occupied = true;
    soundManager.playUiClick();
    this.showToast(v.nameBn, "যানবাহনে উঠেছেন। চালাতে জয়স্টিক বা বাটন ব্যবহার করুন।");
    if (this.onHudUpdate) this.onHudUpdate();
  }

  public exitVehicle() {
    if (!this.player.currentVehicleId) return;
    const v = this.vehicles.find((veh) => veh.id === this.player.currentVehicleId);
    if (v) {
      v.occupied = false;
      v.speed = 0;
      this.player.x = v.x - Math.cos(v.angle + Math.PI / 2) * (v.width + 16);
      this.player.y = v.y - Math.sin(v.angle + Math.PI / 2) * (v.width + 16);
    }
    this.player.currentVehicleId = null;
    soundManager.stopEngine();
    soundManager.playUiClick();
    if (this.onHudUpdate) this.onHudUpdate();
  }

  private update(dt: number) {
    if (this.state !== "PLAYING") return;

    // Day/Night Cycle
    this.timeCycleTimer += dt;
    if (this.timeCycleTimer > 150) {
      this.timeCycleTimer = 0;
      const cycles: TimeOfDay[] = ["morning", "afternoon", "evening", "night"];
      const nextIdx = (cycles.indexOf(this.timeOfDay) + 1) % cycles.length;
      this.timeOfDay = cycles[nextIdx];

      if (this.timeOfDay === "night") {
        this.showToast("রাত নেমেছে!", "সাবধান! রাতে নির্জন পথে ডাকাতদের আনাগোনা থাকে!");
      }
    }

    // Player attack timer
    if (this.player.attackTimer > 0) {
      this.player.attackTimer -= dt;
      if (this.player.attackTimer <= 0) {
        this.player.isAttacking = false;
      }
    }

    // Police Siren timer
    if (this.policeOfficer.isSirenActive) {
      this.policeOfficer.sirenTimer -= dt;
      if (this.policeOfficer.sirenTimer <= 0) {
        this.policeOfficer.isSirenActive = false;
      }
    }

    // Mission timer
    if (this.activeMission && this.missionTimer !== null) {
      this.missionTimer -= dt;
      if (this.missionTimer <= 0) {
        this.missionTimer = 0;
        this.showToast("সময় শেষ!", "মিশন ব্যর্থ হয়েছে। পুনরায় চেষ্টা করুন।");
        this.resetMission();
      }
    }

    // Movement
    if (this.player.currentVehicleId) {
      this.updateDrivenVehicle(dt);
    } else {
      this.updatePlayerMovement(dt);
    }

    // NPCs & Dacoits
    this.updateNPCs(dt);
    this.updateDacoits(dt);
    this.updateParticles(dt);
    this.checkMissionProgress();

    // Camera follow
    const targetX = this.player.currentVehicleId
      ? this.vehicles.find((v) => v.id === this.player.currentVehicleId)?.x || this.player.x
      : this.player.x;
    const targetY = this.player.currentVehicleId
      ? this.vehicles.find((v) => v.id === this.player.currentVehicleId)?.y || this.player.y
      : this.player.y;

    this.camera.x += (targetX - this.camera.x) * 0.12;
    this.camera.y += (targetY - this.camera.y) * 0.12;

    const halfViewW = this.canvas.width / (2 * this.camera.zoom);
    const halfViewH = this.canvas.height / (2 * this.camera.zoom);
    this.camera.x = Math.max(halfViewW, Math.min(WORLD_WIDTH - halfViewW, this.camera.x));
    this.camera.y = Math.max(halfViewH, Math.min(WORLD_HEIGHT - halfViewH, this.camera.y));

    if (this.camera.shake > 0) {
      this.camera.shake = Math.max(0, this.camera.shake - dt * 25);
    }

    if (this.notification) {
      this.notification.timer -= dt;
      if (this.notification.timer <= 0) {
        this.notification = null;
      }
    }
  }

  // --- Player On-Foot Movement ---
  private updatePlayerMovement(dt: number) {
    let dx = 0;
    let dy = 0;

    if (this.joystick.active) {
      dx = this.joystick.x;
      dy = this.joystick.y;
    } else {
      if (this.inputs.left) dx -= 1;
      if (this.inputs.right) dx += 1;
      if (this.inputs.up) dy -= 1;
      if (this.inputs.down) dy += 1;
    }

    const len = Math.hypot(dx, dy);
    if (len > 0) {
      dx /= len;
      dy /= len;

      this.player.isRunning = this.inputs.run;
      const speed = this.player.isRunning ? this.player.runSpeed : this.player.walkSpeed;
      const newX = this.player.x + dx * speed * 60 * dt;
      const newY = this.player.y + dy * speed * 60 * dt;

      if (Math.abs(dx) > Math.abs(dy)) {
        this.player.facing = dx > 0 ? "right" : "left";
      } else {
        this.player.facing = dy > 0 ? "down" : "up";
      }

      if (!this.checkSolidCollision(newX, newY, 12, false)) {
        this.player.x = newX;
        this.player.y = newY;
        this.player.speed = speed;

        this.stepDistance += speed * 60 * dt;
        if (this.stepDistance > 45) {
          this.stepDistance = 0;
          soundManager.playFootstep();
          this.addParticle({
            x: this.player.x,
            y: this.player.y + 6,
            vx: (Math.random() - 0.5) * 4,
            vy: (Math.random() - 0.5) * 4,
            size: 3,
            color: "#b48c59",
            alpha: 0.5,
            life: 0.3,
            maxLife: 0.3,
            type: "dust",
          });
        }
      }
    } else {
      this.player.speed = 0;
    }

    this.player.x = Math.max(35, Math.min(WORLD_WIDTH - 35, this.player.x));
    this.player.y = Math.max(35, Math.min(WORLD_HEIGHT - 35, this.player.y));
  }

  // --- Driving Vehicle Physics & Traffic Violations ---
  private updateDrivenVehicle(dt: number) {
    const v = this.vehicles.find((veh) => veh.id === this.player.currentVehicleId);
    if (!v) return;

    let steer = 0;
    let throttle = 0;

    if (this.joystick.active) {
      steer = this.joystick.x;
      throttle = -this.joystick.y;
    } else {
      if (this.inputs.left) steer -= 1;
      if (this.inputs.right) steer += 1;
      if (this.inputs.up) throttle += 1;
      if (this.inputs.down) throttle -= 1;
    }

    if (Math.abs(v.speed) > 0.1) {
      const dir = v.speed >= 0 ? 1 : -1;
      v.angle += steer * v.turnSpeed * dir * 60 * dt;
    }

    if (throttle > 0) {
      v.speed = Math.min(v.maxSpeed, v.speed + v.accel * 60 * dt);
    } else if (throttle < 0) {
      v.speed = Math.max(-v.maxSpeed * 0.45, v.speed - v.accel * 60 * dt);
    } else {
      v.speed *= 0.94;
      if (Math.abs(v.speed) < 0.05) v.speed = 0;
    }

    const nextX = v.x + Math.cos(v.angle) * v.speed * 60 * dt;
    const nextY = v.y + Math.sin(v.angle) * v.speed * 60 * dt;

    const collided = this.checkSolidCollision(nextX, nextY, v.width / 2, v.isWaterVehicle);

    if (!collided) {
      v.x = nextX;
      v.y = nextY;
    } else {
      if (Math.abs(v.speed) > 2) {
        this.camera.shake = 12;
        v.health = Math.max(0, v.health - 8);
        soundManager.playUiClick();
        if (v.health <= 0) {
          this.showToast("গাড়ি বিকল!", "গাড়িটি নষ্ট হয়ে গেছে। গ্যারেজে মেরামত করুন।");
          this.exitVehicle();
        }
      }
      v.speed = -v.speed * 0.3;
    }

    // Check hit against pedestrians & thugs (Dramatic Vehicle Knockback Ragdoll Physics!)
    if (Math.abs(v.speed) > 1.2) {
      const hitSpeed = Math.abs(v.speed);
      this.npcs.forEach((npc) => {
        if (Math.hypot(npc.x - v.x, npc.y - v.y) < v.width + 12) {
          // Calculate high-impact knockback vector
          const impactAngle = v.angle;
          npc.knockbackVx = Math.cos(impactAngle) * (hitSpeed * 2.5 + 4.0);
          npc.knockbackVy = Math.sin(impactAngle) * (hitSpeed * 2.5 + 4.0);
          npc.knockdownTimer = 2.5; // Ragdoll tumble duration
          npc.state = "knocked_down";

          // Play dramatic impact sounds
          soundManager.playBodyHit();
          soundManager.playCrash();
          soundManager.playTireScreech();

          // Pick random iconic Bengali scream
          const scream = BENGALI_HIT_SCREAMS[Math.floor(Math.random() * BENGALI_HIT_SCREAMS.length)];
          npc.activeDialog = scream;
          npc.dialogTimer = 3.0;

          // Spawn floating shout particle
          this.addParticle({
            type: "shout",
            text: scream,
            x: npc.x,
            y: npc.y - 18,
            vx: npc.knockbackVx * 0.35,
            vy: -2.5,
            size: 8,
            color: "#ef4444",
            alpha: 1,
            life: 2.2,
            maxLife: 2.2,
          });

          // If fast hit, damage NPC, charge fine and raise wanted stars
          if (hitSpeed > 2.6) {
            this.camera.shake = 14;
            const fineAmount = 60;
            this.player.money = Math.max(0, this.player.money - fineAmount);
            this.player.finesDue += fineAmount;
            this.player.wantedLevel = Math.min(3, this.player.wantedLevel + 1);
            soundManager.playFine();
            this.showToast("পথচারী দুর্ঘটনা!", `${scream} বেপরোয়া চালনায় ৳${fineAmount} জরিমানা কাটা হলো!`);
          }
        }
      });
    }

    this.player.x = v.x;
    this.player.y = v.y;
    soundManager.updateEngine(v.type, Math.abs(v.speed) / v.maxSpeed);
  }

  // --- Dacoits Simulation ---
  private updateDacoits(dt: number) {
    this.dacoits.forEach((d) => {
      if (d.isKnockedOut) return;

      const distToPlayer = Math.hypot(this.player.x - d.x, this.player.y - d.y);
      const alertDist = this.timeOfDay === "night" ? 280 : 160;

      if (distToPlayer < alertDist && !this.player.currentVehicleId) {
        d.isChasing = true;
        const angle = Math.atan2(this.player.y - d.y, this.player.x - d.x);
        d.x += Math.cos(angle) * d.speed * 60 * dt;
        d.y += Math.sin(angle) * d.speed * 60 * dt;

        // Robbery / Attack when touching player
        if (distToPlayer < 25) {
          d.attackCooldown -= dt;
          if (d.attackCooldown <= 0) {
            d.attackCooldown = 2.0;
            const stolen = Math.min(this.player.money, 40);
            this.player.money -= stolen;
            this.player.health = Math.max(10, this.player.health - 12);
            soundManager.playPunch();
            this.camera.shake = 10;
            this.showToast("ডাকাতের আক্রমণ!", `ডাকাত লাঠি দিয়ে আঘাত করে ৳${stolen} ছিনতাই করেছে! আত্মরক্ষা করুন!`);
          }
        }
      } else {
        d.isChasing = false;
        if (Math.random() < 0.01) {
          d.x += (Math.random() - 0.5) * 40;
          d.y += (Math.random() - 0.5) * 40;
        }
      }
    });
  }

  // --- Solid Collision with Open Padma Bridge and District Town ---
  private checkSolidCollision(x: number, y: number, radius: number, isWaterVehicle: boolean): boolean {
    if (x < radius + 30 || x > WORLD_WIDTH - radius - 30 || y < radius + 30 || y > WORLD_HEIGHT - radius - 30) {
      return true;
    }

    const riverStart = RIVER_X - 10;
    const riverEnd = RIVER_X + 710;
    // Padma Grand Highway Bridge corridor connects village to district city!
    const isOnPadmaBridge = y >= 1530 && y <= 1660;

    if (isWaterVehicle) {
      // Water vehicles must remain inside Padma river corridor
      if (x < riverStart || x > riverEnd) return true;
    } else {
      // Land vehicles / player cannot swim into river water UNLESS crossing on Padma Bridge!
      if (x > riverStart && x < riverEnd && !isOnPadmaBridge) {
        return true;
      }
    }

    for (const b of this.buildings) {
      if (
        x + radius > b.x &&
        x - radius < b.x + b.w &&
        y + radius > b.y + 15 &&
        y - radius < b.y + b.h
      ) {
        return true;
      }
    }
    return false;
  }

  // --- NPCs Update with Ragdoll Sliding & Hostile Thug AI ---
  private updateNPCs(dt: number) {
    this.npcs.forEach((npc) => {
      // 1. Dialogue timer
      if (npc.dialogTimer && npc.dialogTimer > 0) {
        npc.dialogTimer -= dt;
        if (npc.dialogTimer <= 0) {
          npc.activeDialog = undefined;
        }
      }

      // 2. Ragdoll Knockback Physics (Sliding across ground on vehicle impact)
      if (npc.knockdownTimer && npc.knockdownTimer > 0) {
        npc.x += (npc.knockbackVx || 0) * 60 * dt;
        npc.y += (npc.knockbackVy || 0) * 60 * dt;
        npc.knockbackVx = (npc.knockbackVx || 0) * 0.88;
        npc.knockbackVy = (npc.knockbackVy || 0) * 0.88;
        npc.knockdownTimer -= dt;

        if (npc.knockdownTimer <= 0) {
          npc.state = "walking";
          npc.knockbackVx = 0;
          npc.knockbackVy = 0;
        }
        return;
      }

      // 3. Hostile Thug AI (মাস্তানরা কাছে পেলে আক্রমণ করে)
      if (npc.isHostile && !this.player.currentVehicleId) {
        const distToPlayer = Math.hypot(this.player.x - npc.x, this.player.y - npc.y);
        if (distToPlayer < 190) {
          // Chase player
          const angle = Math.atan2(this.player.y - npc.y, this.player.x - npc.x);
          npc.x += Math.cos(angle) * (npc.speed * 1.3) * 60 * dt;
          npc.y += Math.sin(angle) * (npc.speed * 1.3) * 60 * dt;

          if (distToPlayer < 28 && Math.random() < 0.04) {
            this.player.health = Math.max(10, this.player.health - 6);
            soundManager.playPunch();
            this.camera.shake = 6;
            this.showToast("মাস্তানের ঘুষি!", `${npc.nameBn} আপনাকে ঘুষি মেরেছে! পাল্টা আক্রমণ করুন!`);
            if (this.onHudUpdate) this.onHudUpdate();
          }
          return;
        }
      }

      // 4. Regular peaceful roaming along pathways
      const dist = Math.hypot(npc.targetX - npc.x, npc.targetY - npc.y);
      if (dist > 8) {
        npc.x += (npc.targetX - npc.x) * 0.025;
        npc.y += (npc.targetY - npc.y) * 0.025;
      } else if (Math.random() < 0.03) {
        npc.targetX = npc.x + (Math.random() - 0.5) * 120;
        npc.targetY = npc.y + (Math.random() - 0.5) * 120;
      }
    });
  }

  private updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * 60 * dt;
      p.y += p.vy * 60 * dt;
      p.life -= dt;
      p.alpha = Math.max(0, p.life / p.maxLife);
      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  public addParticle(p: Particle) {
    if (this.particles.length < 150) {
      this.particles.push(p);
    }
  }

  // --- Missions System ---
  public startMission(missionId: number) {
    const mission = MISSIONS.find((m) => m.id === missionId);
    if (!mission) return;

    this.activeMission = { ...mission, hasPickedUp: false };
    this.activeMissionIndex = MISSIONS.indexOf(mission);
    this.missionTimer = mission.timeLimit || null;

    soundManager.playPhoneBeep();
    this.showToast(mission.titleBn, mission.descBn);
    if (this.onHudUpdate) this.onHudUpdate();
  }

  public startNextAvailableMission() {
    const nextMission = MISSIONS.find((m) => !this.completedMissions.includes(m.id)) || MISSIONS[0];
    this.startMission(nextMission.id);
  }

  public resetMission() {
    this.activeMission = null;
    this.missionTimer = null;
    if (this.onHudUpdate) this.onHudUpdate();
  }

  private checkMissionProgress() {
    if (!this.activeMission) return;

    const m = this.activeMission;
    if (m.pickupLocation && !m.hasPickedUp) {
      const distToPickup = Math.hypot(this.player.x - m.pickupLocation.x, this.player.y - m.pickupLocation.y);
      if (distToPickup < m.targetRadius) {
        m.hasPickedUp = true;
        soundManager.playCoin();
        this.showToast("পার্সেল সংগৃহীত!", "এবার লাল চিহ্নিত গন্তব্যে দ্রুত পৌঁছে দিন।");
        if (this.onHudUpdate) this.onHudUpdate();
      }
      return;
    }

    const distToTarget = Math.hypot(this.player.x - m.targetLocation.x, this.player.y - m.targetLocation.y);
    if (distToTarget < m.targetRadius) {
      if (m.requiredVehicle) {
        const curVeh = this.vehicles.find((v) => v.id === this.player.currentVehicleId);
        if (!curVeh || curVeh.type !== m.requiredVehicle) {
          return;
        }
      }
      this.completeMission(m);
    }
  }

  private completeMission(m: Mission) {
    this.player.money += m.rewardMoney;
    if (!this.completedMissions.includes(m.id)) {
      this.completedMissions.push(m.id);
    }

    soundManager.playMissionComplete();
    this.showToast("মিশন সফল!", `আপনি পুরস্কার পেয়েছেন ৳${m.rewardMoney} টাকা!`);

    this.activeMission = null;
    this.missionTimer = null;

    this.saveProgress();
    if (this.onHudUpdate) this.onHudUpdate();
    if (this.onStateChange) this.onStateChange("MISSION_SUCCESS");
  }

  public showToast(title: string, desc: string) {
    this.notification = { title, desc, timer: 4.5 };
    if (this.onHudUpdate) this.onHudUpdate();
  }

  private render(dt: number) {
    this.renderer.render(
      this.player,
      this.vehicles,
      this.npcs,
      this.dacoits,
      this.policeOfficer,
      this.buildings,
      this.particles,
      this.activeMission,
      this.camera,
      this.timeOfDay,
      this.weather,
      dt
    );
  }

  public setState(newState: GameState) {
    this.state = newState;
    if (newState === "PLAYING") {
      soundManager.resume();
    } else {
      soundManager.stopEngine();
    }
    if (this.onStateChange) this.onStateChange(newState);
  }

  public saveProgress() {
    try {
      const data = {
        player: {
          x: this.player.x,
          y: this.player.y,
          money: this.player.money,
          health: this.player.health,
        },
        completedMissions: this.completedMissions,
        settings: this.settings,
        timeOfDay: this.timeOfDay,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch (e) {
      console.warn("Could not save to localStorage", e);
    }
  }

  public loadProgress(): boolean {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);
      if (data.player) {
        this.player.x = data.player.x || 650;
        this.player.y = data.player.y || 460;
        this.player.money = data.player.money ?? 200;
        this.player.health = data.player.health ?? 100;
      }
      if (Array.isArray(data.completedMissions)) {
        this.completedMissions = data.completedMissions;
      }
      if (data.settings) {
        this.settings = { ...this.settings, ...data.settings };
      }
      if (data.timeOfDay) {
        this.timeOfDay = data.timeOfDay;
      }
      return true;
    } catch (e) {
      console.warn("Could not load from localStorage", e);
      return false;
    }
  }

  public resetProgress() {
    localStorage.removeItem(SAVE_KEY);
    this.player.x = 650;
    this.player.y = 460;
    this.player.money = 200;
    this.player.health = 100;
    this.completedMissions = [];
    this.activeMission = { ...MISSIONS[0], hasPickedUp: false };
    this.missionTimer = null;
    if (this.player.currentVehicleId) {
      this.exitVehicle();
    }
    this.saveProgress();
    if (this.onHudUpdate) this.onHudUpdate();
  }
}
