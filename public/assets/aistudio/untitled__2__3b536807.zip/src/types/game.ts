export type GameState = "TITLE" | "INTRO_MODAL" | "PLAYING" | "PAUSED" | "MISSION_SUCCESS" | "GAME_OVER";

export type Language = "bn" | "en";

export interface Position {
  x: number;
  y: number;
}

export interface Velocity {
  vx: number;
  vy: number;
}

export type WeatherType = "clear" | "cloudy" | "rain" | "thunder";

export type TimeOfDay = "morning" | "afternoon" | "evening" | "night";

export interface Region {
  id: string;
  nameBn: string;
  nameEn: string;
  bounds: { x: number; y: number; w: number; h: number };
  color: string;
  descriptionBn: string;
  descriptionEn: string;
  isCity?: boolean;
}

export type InteriorType = 
  | "tea_stall"
  | "grocery_store"
  | "garage_workshop"
  | "police_station"
  | "hospital_clinic"
  | "city_supermarket";

export interface Building {
  id: string;
  nameBn: string;
  nameEn: string;
  type: "house" | "mud_house" | "shop" | "tea_stall" | "school" | "mosque" | "clinic" | "mill" | "garage" | "ferry_ghat" | "bazaar" | "city_building" | "bank" | "police_station";
  x: number;
  y: number;
  w: number;
  h: number;
  roofColor?: string;
  wallColor?: string;
  isEnterable?: boolean;
  interiorType?: InteriorType;
  doorX: number;
  doorY: number;
  floors?: number;
}

export type VehicleType = 
  | "bicycle"
  | "motorcycle"
  | "rickshaw"
  | "easybike"
  | "cng"
  | "private_car"
  | "pickup"
  | "tractor"
  | "laguna"
  | "bus"
  | "cargo_truck"
  | "fishing_boat"
  | "motorboat"
  | "ferry";

export interface Vehicle {
  id: string;
  type: VehicleType;
  nameBn: string;
  nameEn: string;
  x: number;
  y: number;
  angle: number; // in radians
  speed: number;
  maxSpeed: number;
  accel: number;
  turnSpeed: number;
  isWaterVehicle: boolean;
  width: number;
  length: number;
  health: number;
  maxHealth: number;
  color: string;
  occupied: boolean;
  unlocked: boolean;
  price: number;
  isAiDriver?: boolean;
  aiTargetX?: number;
  aiTargetY?: number;
}

export interface NPC {
  id: string;
  nameBn: string;
  nameEn: string;
  roleBn: string;
  roleEn: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  speed: number;
  angle: number;
  state: "idle" | "walking" | "talking" | "farming" | "working" | "fleeing" | "knocked_down";
  speechBn: string[];
  speechEn: string[];
  activeDialog?: string;
  dialogTimer?: number;
  clothingColor: string;
  skinTone: string;
  hasHat?: boolean; // Mathal
  hasPot?: boolean; // Kalshi
  isHostile?: boolean; // Thug / Gangster (গুন্ডা)
  health?: number;
  // Ragdoll on vehicle hit
  knockbackVx?: number;
  knockbackVy?: number;
  knockdownTimer?: number;
}

// Night Dacoits / Outlaws
export interface Dacoit {
  id: string;
  nameBn: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  speed: number;
  health: number;
  maxHealth: number;
  isChasing: boolean;
  attackCooldown: number;
  hasLoot: boolean;
  isKnockedOut: boolean;
  knockbackVx: number;
  knockbackVy: number;
  knockdownTimer: number;
}

// Police Officer
export interface PoliceOfficer {
  id: string;
  nameBn: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  speed: number;
  isSirenActive: boolean;
  sirenTimer: number;
  chasingDacoitId: string | null;
}

export interface Mission {
  id: number;
  titleBn: string;
  titleEn: string;
  descBn: string;
  descEn: string;
  rewardMoney: number;
  targetLocation: Position;
  targetRadius: number;
  pickupLocation?: Position;
  hasPickedUp?: boolean;
  targetRegionBn: string;
  targetRegionEn: string;
  requiredVehicle?: VehicleType;
  timeLimit?: number;
  icon: string;
}

export interface Player {
  x: number;
  y: number;
  angle: number;
  speed: number;
  walkSpeed: number;
  runSpeed: number;
  health: number;
  maxHealth: number;
  money: number;
  currentVehicleId: string | null;
  currentInterior: InteriorType | null;
  isRunning: boolean;
  isInteracting: boolean;
  isAttacking: boolean;
  attackTimer: number;
  facing: "up" | "down" | "left" | "right";
  animFrame: number;
  wantedLevel: number;
  finesDue: number;
  weapon: "fist" | "bamboo_stick";
}

export interface SoundSettings {
  master: number;
  music: number;
  ambient: number;
  vehicles: number;
  sfx: number;
  muted: boolean;
}

export interface GameSettings {
  language: Language;
  graphicsQuality: "low" | "medium" | "high";
  controlType: "dpad" | "joystick";
  controlSize: "small" | "medium" | "large";
  leftHanded: boolean;
  showMinimap: boolean;
  sound: SoundSettings;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  type: "dust" | "water" | "smoke" | "spark" | "firefly" | "leaf" | "rain" | "hit" | "coin" | "shout";
  text?: string;
}
