import React from "react";
import { soundManager } from "../audio/SoundManager";
import { Compass, FileText, Home, Play, RotateCcw, Settings, Volume2, VolumeX } from "lucide-react";
import { GameEngine } from "../game/GameEngine";

interface PauseModalProps {
  engine: GameEngine;
  onResume: () => void;
  onOpenMissions: () => void;
  onOpenMap: () => void;
  onOpenSettings: () => void;
  onMainMenu: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  engine,
  onResume,
  onOpenMissions,
  onOpenMap,
  onOpenSettings,
  onMainMenu,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 font-bangla select-none animate-in fade-in">
      <div className="bg-stone-900 border-2 border-stone-700 rounded-3xl p-6 sm:p-8 max-w-sm w-full text-center shadow-2xl space-y-4">
        <h3 className="text-xl font-bold text-stone-100">খেলা সাময়িক বিরতি (Paused)</h3>
        <p className="text-xs text-stone-400">রাধানগর গ্রাম আপনার জন্য অপেক্ষা করছে।</p>

        <div className="space-y-2 pt-2">
          <button
            onClick={() => {
              soundManager.playUiClick();
              onResume();
            }}
            className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg flex items-center justify-center gap-2 active:scale-95"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>খেলা চালিয়ে যান (Resume)</span>
          </button>

          <button
            onClick={() => {
              soundManager.playUiClick();
              onOpenMissions();
            }}
            className="w-full py-2.5 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs flex items-center justify-center gap-2"
          >
            <FileText className="w-4 h-4 text-rose-400" />
            <span>মিশন তালিকা</span>
          </button>

          <button
            onClick={() => {
              soundManager.playUiClick();
              onOpenMap();
            }}
            className="w-full py-2.5 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs flex items-center justify-center gap-2"
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span>সম্পূর্ণ ম্যাপ</span>
          </button>

          <button
            onClick={() => {
              soundManager.playUiClick();
              onOpenSettings();
            }}
            className="w-full py-2.5 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs flex items-center justify-center gap-2"
          >
            <Settings className="w-4 h-4 text-stone-400" />
            <span>সেটিংস</span>
          </button>

          <button
            onClick={() => {
              soundManager.playUiClick();
              engine.saveProgress();
              onMainMenu();
            }}
            className="w-full py-2.5 rounded-2xl bg-stone-800/80 hover:bg-stone-700 text-stone-400 hover:text-stone-200 font-semibold text-xs flex items-center justify-center gap-2"
          >
            <Home className="w-4 h-4" />
            <span>প্রধান মেনুতে ফিরুন (Main Menu)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
