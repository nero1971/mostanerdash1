import React from "react";
import { soundManager } from "../audio/SoundManager";
import { CheckCircle2, Play, Sparkles, Trophy } from "lucide-react";

interface MissionSuccessModalProps {
  onContinue: () => void;
  rewardMoney: number;
  completedCount: number;
  totalMissions: number;
}

export const MissionSuccessModal: React.FC<MissionSuccessModalProps> = ({
  onContinue,
  rewardMoney,
  completedCount,
  totalMissions,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-bangla select-none animate-in fade-in zoom-in-95">
      <div className="bg-stone-900 border-2 border-emerald-400 rounded-3xl p-6 sm:p-8 max-w-sm w-full text-center shadow-2xl relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-40 h-40 bg-emerald-500/20 rounded-full blur-2xl" />

        <div className="w-16 h-16 rounded-full bg-emerald-600/30 border-2 border-emerald-400 flex items-center justify-center mx-auto shadow-xl text-emerald-400">
          <Trophy className="w-8 h-8" />
        </div>

        <h3 className="text-xl font-bold text-emerald-300 mt-4">মিশন সফল হয়েছে!</h3>
        <p className="text-xs text-stone-300 mt-1">রাধানগরবাসী আপনার সেবায় মুগ্ধ।</p>

        <div className="my-5 p-4 rounded-2xl bg-stone-950 border border-stone-800 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-stone-400">অর্জিত নগদ পুরস্কার:</span>
            <span className="text-base font-bold text-amber-400 tabular-nums">+৳{rewardMoney} টাকা</span>
          </div>
          <div className="flex justify-between items-center text-xs">
            <span className="text-stone-400">সম্পন্ন মিশন:</span>
            <span className="font-bold text-emerald-400 tabular-nums">{completedCount} / {totalMissions}</span>
          </div>
        </div>

        <button
          onClick={() => {
            soundManager.playUiClick();
            onContinue();
          }}
          className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold rounded-2xl shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-all text-sm"
        >
          <Play className="w-4 h-4 fill-white" />
          <span>পরবর্তী অনুসন্ধানে যান (Continue)</span>
        </button>
      </div>
    </div>
  );
};
