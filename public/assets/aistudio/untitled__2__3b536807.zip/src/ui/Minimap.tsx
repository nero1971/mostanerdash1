import React from "react";
import { GameEngine } from "../game/GameEngine";
import { REGIONS, RIVER_X, WORLD_HEIGHT, WORLD_WIDTH } from "../game/constants";
import { Compass, Maximize2 } from "lucide-react";

interface MinimapProps {
  engine: GameEngine;
  onOpenFullMap: () => void;
}

export const Minimap: React.FC<MinimapProps> = ({ engine, onOpenFullMap }) => {
  const mapCanvasRef = React.useRef<HTMLCanvasElement | null>(null);

  React.useEffect(() => {
    let animId: number;

    const renderMinimap = () => {
      const canvas = mapCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const w = canvas.width;
      const h = canvas.height;
      const scaleX = w / WORLD_WIDTH;
      const scaleY = h / WORLD_HEIGHT;

      // Base background
      ctx.fillStyle = "#2d5e2e";
      ctx.fillRect(0, 0, w, h);

      // Padma River
      ctx.fillStyle = "#0284c7";
      ctx.fillRect(RIVER_X * scaleX, 0, (WORLD_WIDTH - RIVER_X) * scaleX, h);

      // Roads
      ctx.fillStyle = "#78350f";
      // Highway
      ctx.fillRect(0, 1530 * scaleY, RIVER_X * scaleX, 90 * scaleY);
      // Village dirt road
      ctx.fillRect(1000 * scaleX, 200 * scaleY, 75 * scaleX, 2200 * scaleY);
      ctx.fillRect(1000 * scaleX, 960 * scaleY, 950 * scaleX, 70 * scaleY);

      // Key regions
      ctx.fillStyle = "rgba(250, 204, 21, 0.25)";
      REGIONS.forEach((r) => {
        ctx.fillRect(r.bounds.x * scaleX, r.bounds.y * scaleY, r.bounds.w * scaleX, r.bounds.h * scaleY);
      });

      // Buildings
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
      engine.buildings.forEach((b) => {
        ctx.fillRect(b.x * scaleX, b.y * scaleY, Math.max(2, b.w * scaleX), Math.max(2, b.h * scaleY));
      });

      // Active Mission Marker
      if (engine.activeMission) {
        const target = engine.activeMission.pickupLocation && !engine.activeMission.hasPickedUp
          ? engine.activeMission.pickupLocation
          : engine.activeMission.targetLocation;
        ctx.fillStyle = "#ef4444";
        ctx.beginPath();
        ctx.arc(target.x * scaleX, target.y * scaleY, 4, 0, Math.PI * 2);
        ctx.fill();
      }

      // Vehicles
      ctx.fillStyle = "#38bdf8";
      engine.vehicles.forEach((v) => {
        if (!v.occupied) {
          ctx.fillRect(v.x * scaleX - 1.5, v.y * scaleY - 1.5, 3, 3);
        }
      });

      // Player Arrow
      const px = engine.player.x * scaleX;
      const py = engine.player.y * scaleY;

      ctx.save();
      ctx.translate(px, py);
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(0, 0, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#16a34a";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();

      animId = requestAnimationFrame(renderMinimap);
    };

    animId = requestAnimationFrame(renderMinimap);
    return () => cancelAnimationFrame(animId);
  }, [engine]);

  return (
    <div
      onClick={onOpenFullMap}
      className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-2xl overflow-hidden border-2 border-emerald-500/60 shadow-xl bg-stone-900/90 backdrop-blur-md cursor-pointer hover:border-emerald-400 transition-all pointer-events-auto group"
      title="ম্যাপ দেখতে ট্যাপ করুন (Tap to open full map)"
    >
      <canvas
        ref={mapCanvasRef}
        width={144}
        height={144}
        className="w-full h-full object-cover"
      />
      <div className="absolute top-1.5 left-1.5 bg-black/60 px-1.5 py-0.5 rounded text-[10px] font-bold text-emerald-400 flex items-center gap-1">
        <Compass className="w-3 h-3 text-red-400" />
        <span>রাধানগর</span>
      </div>
      <div className="absolute bottom-1 right-1 bg-black/60 p-1 rounded-md text-stone-300 group-hover:text-white">
        <Maximize2 className="w-3 h-3" />
      </div>
    </div>
  );
};
