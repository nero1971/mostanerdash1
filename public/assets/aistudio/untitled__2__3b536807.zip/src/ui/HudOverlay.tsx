import React from "react";
import { GameEngine } from "../game/GameEngine";
import { soundManager } from "../audio/SoundManager";
import { Minimap } from "./Minimap";
import {
  Bell,
  Clock,
  Compass,
  Gauge,
  Heart,
  Pause,
  Play,
  Volume2,
  VolumeX,
  Wallet,
  Zap,
} from "lucide-react";

interface HudOverlayProps {
  engine: GameEngine;
  onOpenMap: () => void;
  onOpenPhone: () => void;
  onPause: () => void;
}

export const HudOverlay: React.FC<HudOverlayProps> = ({
  engine,
  onOpenMap,
  onOpenPhone,
  onPause,
}) => {
  const currentVeh = engine.vehicles.find((v) => v.id === engine.player.currentVehicleId);
  const activeMission = engine.activeMission;

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex flex-col justify-between p-3 sm:p-5 font-bangla">
      {/* Top Perimeter Cluster */}
      <div className="w-full flex justify-between items-start">
        {/* Top-Left: Player Status Cluster */}
        <div className="flex flex-col gap-1.5 pointer-events-auto">
          {/* Health & Money */}
          <div className="flex items-center gap-2 bg-stone-950/80 border border-emerald-500/40 px-3 py-1.5 rounded-2xl shadow-xl">
            {/* Health */}
            <div className="flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
              <div className="w-20 sm:w-24 h-2 bg-stone-800 rounded-full overflow-hidden border border-stone-700">
                <div
                  style={{ width: `${engine.player.health}%` }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-green-400 transition-all duration-300"
                />
              </div>
              <span className="text-[11px] font-bold text-stone-200 tabular-nums">
                {engine.player.health}%
              </span>
            </div>

            <span className="text-stone-600">|</span>

            {/* Money (টাকা) */}
            <div className="flex items-center gap-1">
              <span className="text-xs font-bold text-amber-400">৳</span>
              <span className="text-xs sm:text-sm font-bold text-amber-300 tabular-nums">
                {engine.player.money}
              </span>
            </div>
          </div>

          {/* Vehicle Info if Driving */}
          {currentVeh && (
            <div className="flex items-center gap-2 bg-stone-950/80 border border-cyan-500/40 px-3 py-1 rounded-xl shadow-lg">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[11px] font-bold text-cyan-200">{currentVeh.nameBn}</span>
              <span className="text-[10px] text-stone-400 tabular-nums">
                {Math.round(Math.abs(currentVeh.speed) * 12)} কিমি/ঘণ্টা
              </span>
            </div>
          )}

          {/* Traffic Fine Penalty Status */}
          {engine.player.finesDue > 0 && (
            <div className="flex items-center gap-1.5 bg-rose-950/90 border border-rose-500/60 px-2.5 py-0.5 rounded-xl shadow text-[10px] text-rose-300 font-bold">
              <span>ট্রাফিক জরিমানা: ৳{engine.player.finesDue}</span>
            </div>
          )}

          {/* Police Active Badge */}
          {engine.policeOfficer.isSirenActive && (
            <div className="flex items-center gap-1.5 bg-blue-950/90 border border-blue-400 px-2.5 py-0.5 rounded-xl shadow text-[10px] text-blue-300 font-bold animate-pulse">
              <span>🚨 পুলিশ টহলে রয়েছে!</span>
            </div>
          )}

          {/* Wanted Stars (পুলিশ ওয়ান্টেড লেভেল) */}
          {engine.player.wantedLevel > 0 && (
            <div className="flex items-center gap-1 bg-rose-950/90 border border-rose-500/80 px-2.5 py-1 rounded-xl shadow text-amber-400 font-black text-xs">
              <span className="text-rose-300 font-bold mr-1">পুলিশ সতর্কতা:</span>
              {Array.from({ length: 3 }).map((_, i) => (
                <span
                  key={i}
                  className={
                    i < engine.player.wantedLevel
                      ? "text-amber-400 drop-shadow animate-pulse text-sm"
                      : "text-stone-600 text-sm"
                  }
                >
                  ★
                </span>
              ))}
            </div>
          )}

          {/* Interior Shop Active Exit Alert */}
          {engine.player.currentInterior && (
            <button
              onClick={() => engine.handleActionPress()}
              className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-green-600 border border-white text-white rounded-xl text-xs font-black shadow-2xl flex items-center gap-1.5 animate-pulse cursor-pointer"
            >
              <span>🚪 দোকান থেকে বের হন (EXIT)</span>
            </button>
          )}

          {/* Quick HUD Navigation Buttons */}
          <div className="flex flex-wrap gap-1 mt-1">
            <button
              onClick={() => {
                soundManager.playUiClick();
                engine.startNextAvailableMission();
              }}
              className="px-2.5 py-1 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 border border-amber-300 text-white rounded-xl text-[11px] font-bold shadow-lg active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>⭐ মিশন শুরু</span>
            </button>

            <button
              onClick={() => {
                soundManager.playUiClick();
                onOpenPhone();
              }}
              className="px-2.5 py-1 bg-stone-900/95 hover:bg-stone-800 border border-emerald-500/60 text-emerald-300 rounded-xl text-[11px] font-bold shadow-lg active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>📱 ফোন</span>
            </button>

            <button
              onClick={() => {
                soundManager.playUiClick();
                onOpenMap();
              }}
              className="px-2.5 py-1 bg-stone-900/95 hover:bg-stone-800 border border-emerald-500/60 text-emerald-300 rounded-xl text-[11px] font-bold shadow-lg active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>🗺️ ম্যাপ</span>
            </button>

            <button
              onClick={() => {
                engine.callPolice();
              }}
              className="px-2.5 py-1 bg-rose-700 hover:bg-rose-600 border border-rose-300 text-white rounded-xl text-[11px] font-bold shadow-lg active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>🚨 পুলিশ</span>
            </button>

            <button
              onClick={() => {
                soundManager.playUiClick();
                engine.setState("INTRO_MODAL");
              }}
              className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-700 border border-emerald-400 text-emerald-100 rounded-xl text-[11px] font-bold shadow-lg active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
            >
              <span>📜 বাপের রাস্তা</span>
            </button>
          </div>
        </div>

        {/* Top-Center: Active Mission Tracker Banner */}
        {activeMission && (
          <div className="hidden sm:flex flex-col items-center bg-stone-950/90 border border-rose-500/50 px-4 py-2 rounded-2xl shadow-2xl pointer-events-auto max-w-sm text-center">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <span>{activeMission.titleBn}</span>
              {engine.missionTimer !== null && (
                <span className="ml-2 px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 text-[10px] flex items-center gap-1 font-mono tabular-nums">
                  <Clock className="w-3 h-3" />
                  {Math.ceil(engine.missionTimer)}s
                </span>
              )}
            </div>
            <p className="text-[11px] text-stone-300 mt-0.5 line-clamp-1">{activeMission.descBn}</p>
          </div>
        )}

        {/* Top-Right: Minimap & Quick Actions */}
        <div className="flex flex-col items-end gap-2">
          {engine.settings.showMinimap && (
            <Minimap engine={engine} onOpenFullMap={onOpenMap} />
          )}

          {/* Quick Pause & Mute buttons */}
          <div className="flex gap-1.5 pointer-events-auto">
            <button
              onClick={() => {
                const next = !engine.settings.sound.muted;
                engine.settings.sound.muted = next;
                soundManager.updateVolumes(engine.settings.sound);
              }}
              className="p-1.5 rounded-xl bg-stone-950/80 border border-stone-700 text-stone-300 hover:text-white shadow"
              title="সাউন্ড"
            >
              {engine.settings.sound.muted ? (
                <VolumeX className="w-3.5 h-3.5 text-rose-400" />
              ) : (
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              )}
            </button>

            <button
              onClick={onPause}
              className="p-1.5 rounded-xl bg-stone-950/80 border border-stone-700 text-stone-300 hover:text-white shadow"
              title="পজ (Esc)"
            >
              <Pause className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Center Toast Notification (Dialogue or Mission Pickup) */}
      {engine.notification && (
        <div className="self-center mb-24 sm:mb-12 max-w-md bg-stone-950/95 border-2 border-emerald-500/70 p-3 sm:p-4 rounded-2xl shadow-2xl text-center pointer-events-auto animate-in slide-in-from-bottom-4 duration-200">
          <h4 className="text-xs sm:text-sm font-bold text-emerald-300">{engine.notification.title}</h4>
          <p className="text-xs text-stone-200 mt-1 leading-relaxed">{engine.notification.desc}</p>
        </div>
      )}

      {/* Bottom Mission Banner on small screens */}
      {activeMission && (
        <div className="sm:hidden self-center mb-1 bg-stone-950/90 border border-rose-500/60 px-3 py-1.5 rounded-xl text-center pointer-events-auto shadow-lg max-w-[90%]">
          <div className="text-[11px] font-bold text-rose-400 flex items-center justify-center gap-1">
            <span>{activeMission.titleBn}</span>
            {engine.missionTimer !== null && (
              <span className="text-amber-400 font-mono">({Math.ceil(engine.missionTimer)}s)</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
