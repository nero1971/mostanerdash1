import React, { useState } from "react";
import { GameEngine } from "../game/GameEngine";
import { soundManager } from "../audio/SoundManager";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Bell,
  Car,
  Footprints,
  LogOut,
  Swords,
  Zap,
} from "lucide-react";

interface VirtualControlsProps {
  engine: GameEngine;
  onOpenPhone: () => void;
  onOpenMap: () => void;
}

export const VirtualControls: React.FC<VirtualControlsProps> = ({
  engine,
  onOpenPhone,
  onOpenMap,
}) => {
  const [isRunning, setIsRunning] = useState(false);

  // Active directional button indicators
  const [activeDirs, setActiveDirs] = useState({
    up: false,
    down: false,
    left: false,
    right: false,
  });

  const inVehicle = !!engine.player.currentVehicleId;
  const currentVeh = inVehicle
    ? engine.vehicles.find((v) => v.id === engine.player.currentVehicleId)
    : null;

  const setDirection = (dir: "up" | "down" | "left" | "right", active: boolean) => {
    soundManager.resume();
    engine.inputs[dir] = active;
    setActiveDirs((prev) => ({ ...prev, [dir]: active }));
  };

  const toggleRun = () => {
    soundManager.resume();
    const next = !isRunning;
    setIsRunning(next);
    engine.inputs.run = next;
  };

  const handleTurboBoost = () => {
    if (!currentVeh) return;
    soundManager.resume();
    currentVeh.speed = Math.min(currentVeh.maxSpeed * 1.4, currentVeh.speed + 4.5);
    soundManager.playHorn(currentVeh.type);
    engine.showToast(currentVeh.nameBn, "⚡ টার্বো স্পিড বুস্ট চালু!");
  };

  return (
    <div className="fixed inset-0 pointer-events-none select-none z-40 font-bangla">
      {/* ========================================================
          BOTTOM CONTROLS BAR: Firmly placed above mobile navigation
         ======================================================== */}
      <div className="fixed bottom-6 sm:bottom-4 left-0 right-0 px-2 sm:px-6 flex justify-between items-end pointer-events-auto">
        {/* ========================================================
            LEFT SIDE: TACTILE DIRECTIONAL D-PAD
            (Adapts: Walking Forward/Back vs Driving Gas/Brake)
           ======================================================== */}
        <div className="flex flex-col items-center">
          <div className="text-[10px] font-bold text-emerald-300 bg-stone-950/95 border border-emerald-500/60 px-2.5 py-0.5 rounded-full mb-1 shadow-lg">
            {inVehicle ? "🚗 গাড়ি ড্রাইভ / স্টিয়ারিং" : "🚶 হাঁটার কন্ট্রোল (Move)"}
          </div>

          <div className="relative w-36 h-36 sm:w-44 sm:h-44 bg-stone-950/95 border-2 border-emerald-500/80 rounded-3xl p-1.5 flex items-center justify-center shadow-2xl backdrop-blur-md">
            {/* UP BUTTON: Walk Forward / Gas Pedal */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setDirection("up", true);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setDirection("up", false);
              }}
              onMouseDown={() => setDirection("up", true)}
              onMouseUp={() => setDirection("up", false)}
              className={`absolute top-1 left-1/2 -translate-x-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl active:scale-90 transition-all ${
                activeDirs.up
                  ? "bg-emerald-300 border-white text-stone-950 scale-95"
                  : inVehicle
                  ? "bg-gradient-to-t from-emerald-700 to-green-600 border-green-300 text-white"
                  : "bg-emerald-600 border-emerald-300 text-white"
              }`}
            >
              <ArrowUp className="w-6 h-6 stroke-[3]" />
              <span className="text-[8px] font-black uppercase tracking-tighter">
                {inVehicle ? "গ্যাস" : "সামনে"}
              </span>
            </button>

            {/* DOWN BUTTON: Walk Back / Brake & Reverse */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setDirection("down", true);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setDirection("down", false);
              }}
              onMouseDown={() => setDirection("down", true)}
              onMouseUp={() => setDirection("down", false)}
              className={`absolute bottom-1 left-1/2 -translate-x-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl active:scale-90 transition-all ${
                activeDirs.down
                  ? "bg-emerald-300 border-white text-stone-950 scale-95"
                  : inVehicle
                  ? "bg-gradient-to-b from-rose-700 to-red-600 border-red-300 text-white"
                  : "bg-emerald-600 border-emerald-300 text-white"
              }`}
            >
              <ArrowDown className="w-6 h-6 stroke-[3]" />
              <span className="text-[8px] font-black uppercase tracking-tighter">
                {inVehicle ? "ব্রেক" : "পেছনে"}
              </span>
            </button>

            {/* LEFT BUTTON: Steer Left */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setDirection("left", true);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setDirection("left", false);
              }}
              onMouseDown={() => setDirection("left", true)}
              onMouseUp={() => setDirection("left", false)}
              className={`absolute left-1 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl active:scale-90 transition-all ${
                activeDirs.left
                  ? "bg-emerald-300 border-white text-stone-950 scale-95"
                  : "bg-emerald-600 border-emerald-300 text-white"
              }`}
            >
              <ArrowLeft className="w-6 h-6 stroke-[3]" />
              <span className="text-[8px] font-black uppercase tracking-tighter">বামে</span>
            </button>

            {/* RIGHT BUTTON: Steer Right */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                setDirection("right", true);
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                setDirection("right", false);
              }}
              onMouseDown={() => setDirection("right", true)}
              onMouseUp={() => setDirection("right", false)}
              className={`absolute right-1 top-1/2 -translate-y-1/2 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl active:scale-90 transition-all ${
                activeDirs.right
                  ? "bg-emerald-300 border-white text-stone-950 scale-95"
                  : "bg-emerald-600 border-emerald-300 text-white"
              }`}
            >
              <ArrowRight className="w-6 h-6 stroke-[3]" />
              <span className="text-[8px] font-black uppercase tracking-tighter">ডানে</span>
            </button>

            {/* Center Visual Indicator */}
            <div className="w-7 h-7 rounded-full bg-emerald-400/30 border border-emerald-300/60 flex items-center justify-center text-[11px] font-bold text-white">
              {inVehicle ? "🏎️" : "🚶"}
            </div>
          </div>
        </div>

        {/* ========================================================
            RIGHT SIDE: DYNAMIC ACTION BUTTONS
           ======================================================== */}
        <div className="flex flex-col gap-2 items-end">
          {/* Sub-actions Row: Horn, Punch/Attack, Sprint/Turbo */}
          <div className="flex gap-2">
            {/* Horn / Bell Button */}
            <button
              onTouchStart={(e) => {
                e.preventDefault();
                engine.inputs.horn = true;
                engine.handleHornPress();
              }}
              onTouchEnd={(e) => {
                e.preventDefault();
                engine.inputs.horn = false;
              }}
              onMouseDown={() => {
                engine.inputs.horn = true;
                engine.handleHornPress();
              }}
              onMouseUp={() => {
                engine.inputs.horn = false;
              }}
              className="w-13 h-13 sm:w-16 sm:h-16 rounded-2xl bg-amber-600 hover:bg-amber-500 border-2 border-amber-300 text-white shadow-2xl flex flex-col items-center justify-center active:scale-90 transition-all font-bold"
              title="হর্ন বা ঘণ্টি বাজান"
            >
              <Bell className="w-5 h-5 text-amber-100" />
              <span className="text-[9px] mt-0.5 font-bold">
                {inVehicle ? "হর্ন" : "ঘণ্টি"}
              </span>
            </button>

            {/* Attack / Fight Button (ON FOOT) */}
            {!inVehicle && (
              <button
                onTouchStart={(e) => {
                  e.preventDefault();
                  engine.handleAttack();
                }}
                onMouseDown={() => {
                  engine.handleAttack();
                }}
                className="w-13 h-13 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-red-600 via-orange-600 to-amber-500 border-2 border-orange-200 text-white shadow-2xl flex flex-col items-center justify-center active:scale-90 transition-all font-bold animate-pulse"
                title="ডাকাতকে ঘুষি মারুন / আত্মরক্ষা"
              >
                <Swords className="w-5 h-5 text-yellow-100" />
                <span className="text-[9px] mt-0.5 font-bold">ঘুষি / মার</span>
              </button>
            )}

            {/* Turbo Boost (IN VEHICLE) */}
            {inVehicle && (
              <button
                onClick={handleTurboBoost}
                className="w-13 h-13 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 border-2 border-cyan-300 text-white shadow-2xl flex flex-col items-center justify-center active:scale-90 transition-all font-bold"
                title="টার্বো বুস্ট!"
              >
                <Zap className="w-5 h-5 text-yellow-300" />
                <span className="text-[9px] mt-0.5 font-bold">টার্বো</span>
              </button>
            )}

            {/* Sprint Button (ON FOOT) */}
            {!inVehicle && (
              <button
                onClick={toggleRun}
                className={`w-13 h-13 sm:w-16 sm:h-16 rounded-2xl border-2 flex flex-col items-center justify-center active:scale-90 transition-all font-bold shadow-2xl ${
                  isRunning
                    ? "bg-rose-600 border-white text-white animate-bounce"
                    : "bg-stone-800/95 border-stone-500 text-stone-200 hover:bg-stone-700"
                }`}
                title="দৌড়ান"
              >
                <Footprints className="w-5 h-5" />
                <span className="text-[9px] mt-0.5 font-bold">{isRunning ? "দৌড় চালু" : "দৌড়"}</span>
              </button>
            )}
          </div>

          {/* Primary Action Button: Enter/Exit Vehicle or Talk */}
          <button
            onTouchStart={(e) => {
              e.preventDefault();
              engine.inputs.action = true;
              engine.handleActionPress();
            }}
            onTouchEnd={(e) => {
              e.preventDefault();
              engine.inputs.action = false;
            }}
            onMouseDown={() => {
              engine.inputs.action = true;
              engine.handleActionPress();
            }}
            onMouseUp={() => {
              engine.inputs.action = false;
            }}
            className={`w-full py-3 sm:py-3.5 px-5 rounded-2xl border-2 shadow-2xl font-bold flex items-center justify-center gap-2 text-xs sm:text-sm active:scale-95 transition-all ${
              inVehicle
                ? "bg-gradient-to-r from-rose-700 to-red-600 border-rose-300 text-white hover:bg-rose-600"
                : "bg-gradient-to-r from-emerald-600 to-green-600 border-emerald-300 text-white hover:bg-emerald-500"
            }`}
          >
            {engine.player.currentInterior ? (
              <>
                <LogOut className="w-5 h-5 text-emerald-200" />
                <span>🚪 দোকান থেকে বের হন (Exit)</span>
              </>
            ) : inVehicle ? (
              <>
                <LogOut className="w-5 h-5 text-rose-200" />
                <span>🚪 গাড়ি থেকে নামুন (Exit)</span>
              </>
            ) : (
              <>
                <Car className="w-5 h-5 text-emerald-200" />
                <span>🛒 দোকানে ঢুকুন / গাড়িতে উঠুন (E)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
