import React, { useRef, useEffect, useState } from "react";
import { GameEngine } from "../game/GameEngine";
import { soundManager } from "../audio/SoundManager";
import { REGIONS, RIVER_X, WORLD_HEIGHT, WORLD_WIDTH } from "../game/constants";
import { Region } from "../types/game";
import { Compass, MapPin, Navigation, X } from "lucide-react";

interface WorldMapModalProps {
  engine: GameEngine;
  onClose: () => void;
}

export const WorldMapModal: React.FC<WorldMapModalProps> = ({ engine, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<Region | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const sx = w / WORLD_WIDTH;
    const sy = h / WORLD_HEIGHT;

    // Background grass
    ctx.fillStyle = "#366a36";
    ctx.fillRect(0, 0, w, h);

    // Padma River
    ctx.fillStyle = "#0284c7";
    ctx.fillRect(RIVER_X * sx, 0, (WORLD_WIDTH - RIVER_X) * sx, h);

    // River label
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.font = "bold 12px 'Hind Siliguri', sans-serif";
    ctx.fillText("পদ্মা নদী (Padma River)", RIVER_X * sx + 15, h / 2);

    // Highway
    ctx.fillStyle = "#52525b";
    ctx.fillRect(0, 1530 * sy, RIVER_X * sx, 90 * sy);

    // Dirt Roads
    ctx.fillStyle = "#b48c59";
    ctx.fillRect(1000 * sx, 200 * sy, 75 * sx, 2200 * sy);
    ctx.fillRect(1000 * sx, 960 * sy, 950 * sx, 70 * sy);
    ctx.fillRect(1950 * sx, 480 * sy, (RIVER_X - 1950) * sx, 75 * sy);

    // Regions highlights
    REGIONS.forEach((r) => {
      ctx.fillStyle = `${r.color}33`; // semi-transparent
      ctx.fillRect(r.bounds.x * sx, r.bounds.y * sy, r.bounds.w * sx, r.bounds.h * sy);
      ctx.strokeStyle = r.color;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(r.bounds.x * sx, r.bounds.y * sy, r.bounds.w * sx, r.bounds.h * sy);

      // Label
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 9px 'Hind Siliguri', sans-serif";
      ctx.fillText(r.nameBn.split(".")[1] || r.nameBn, r.bounds.x * sx + 4, r.bounds.y * sy + 14);
    });

    // Buildings
    ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
    engine.buildings.forEach((b) => {
      ctx.fillRect(b.x * sx, b.y * sy, Math.max(3, b.w * sx), Math.max(3, b.h * sy));
    });

    // Vehicles
    ctx.fillStyle = "#38bdf8";
    engine.vehicles.forEach((v) => {
      ctx.fillRect(v.x * sx - 2, v.y * sy - 2, 4, 4);
    });

    // Active Mission Beacon
    if (engine.activeMission) {
      const target = engine.activeMission.pickupLocation && !engine.activeMission.hasPickedUp
        ? engine.activeMission.pickupLocation
        : engine.activeMission.targetLocation;
      ctx.fillStyle = "#ef4444";
      ctx.beginPath();
      ctx.arc(target.x * sx, target.y * sy, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    // Player Marker
    const px = engine.player.x * sx;
    const py = engine.player.y * sy;
    ctx.fillStyle = "#22c55e";
    ctx.beginPath();
    ctx.arc(px, py, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.stroke();
  }, [engine]);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex flex-col p-3 sm:p-6 text-stone-100 font-bangla animate-in fade-in">
      {/* Top Header */}
      <div className="flex justify-between items-center pb-3 border-b border-stone-800">
        <div className="flex items-center gap-2">
          <Compass className="w-6 h-6 text-emerald-400" />
          <div>
            <h2 className="text-base sm:text-lg font-bold text-emerald-300">
              রাধানগর সম্পূর্ণ জেলা মানচিত্র (Full World Map)
            </h2>
            <p className="text-[11px] text-stone-400">১৬টি সংযুক্ত গ্রামীণ অঞ্চল ও নদী তীর</p>
          </div>
        </div>

        <button
          onClick={() => {
            soundManager.playUiClick();
            onClose();
          }}
          className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Map View & Region Info */}
      <div className="flex-1 flex flex-col lg:flex-row gap-4 mt-3 overflow-hidden">
        {/* Map Canvas */}
        <div className="flex-1 rounded-3xl overflow-hidden border-2 border-stone-700 bg-stone-950 flex items-center justify-center p-2">
          <canvas
            ref={canvasRef}
            width={720}
            height={560}
            className="w-full h-full object-contain cursor-crosshair rounded-2xl"
          />
        </div>

        {/* Region List & Details */}
        <div className="w-full lg:w-80 flex flex-col gap-3 bg-stone-900/90 border border-stone-800 rounded-3xl p-4 overflow-y-auto">
          <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">অঞ্চল তালিকা (Regions)</h3>
          <div className="space-y-2 flex-1 overflow-y-auto pr-1">
            {REGIONS.map((r) => (
              <div
                key={r.id}
                onClick={() => {
                  soundManager.playUiClick();
                  setSelectedRegion(r);
                }}
                className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                  selectedRegion?.id === r.id
                    ? "bg-emerald-950 border-emerald-400 text-white"
                    : "bg-stone-950/60 border-stone-800 text-stone-300 hover:border-emerald-500/40"
                }`}
              >
                <div className="font-bold">{r.nameBn}</div>
                <p className="text-[10px] text-stone-400 mt-1 line-clamp-2">{r.descriptionBn}</p>
              </div>
            ))}
          </div>

          {selectedRegion && (
            <div className="p-3 rounded-2xl bg-stone-950 border border-emerald-500/40 mt-2">
              <h4 className="font-bold text-xs text-emerald-300">{selectedRegion.nameBn}</h4>
              <p className="text-[11px] text-stone-300 mt-1">{selectedRegion.descriptionBn}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
